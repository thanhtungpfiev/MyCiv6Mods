-- ===========================================================================
-- Better Leader Icon
-- Author: Infixo
-- 2019-03-21: Created
-- ===========================================================================

-- just to make versioning easier
INSERT INTO GlobalParameters (Name, Value) VALUES ('BLI_VERSION_MAJOR', '2');
INSERT INTO GlobalParameters (Name, Value) VALUES ('BLI_VERSION_MINOR', '3');

-- options
INSERT INTO GlobalParameters (Name, Value) VALUES ('BLI_OPTION_RELATIONSHIP', '1');

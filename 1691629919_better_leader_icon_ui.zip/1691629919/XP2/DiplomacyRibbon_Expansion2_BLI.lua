print("BLI: Loading DiplomacyRibbon_Expansion2_BLI.lua from Better Leader Icon v"..GlobalParameters.BLI_VERSION_MAJOR.."."..GlobalParameters.BLI_VERSION_MINOR);
-- ===========================================================================
-- Better Leader Icon
-- Author: Infixo
-- 2019-03-21: Created
-- ===========================================================================

-- nothing to do here, I just need to start with the original file
include("DiplomacyRibbon_Expansion2");


print("BLI: Loaded DiplomacyRibbon_Expansion2_BLI.lua OK");

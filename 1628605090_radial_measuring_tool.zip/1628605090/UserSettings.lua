-- UserSettings
-- Author: Zur13
-- DateCreated: 3/9/2019 4:10:37 PM
--------------------------------------------------------------

-- ### READ ME FIRST ###
--
-- This is the default settings file example. All changes you made here will NOT be used by the mod.
-- You should make a copy of this file and rename the copy to UserSettings.lua 
-- the settings from that file will be used by the mod and it will not be rewrite with mod updates.
-- 
-- FILE FORMAT
-- Two minus signs "--" is the comment line all symbols after the two minus signs are ignored by the mod.
--
-- Option line format:
--
-- local OPTION_NAME = OPTION_VALUE ; -- OPTION COMMENT
-- 
-- "local"        - is the required keyword do not change it.
-- "OPTION_NAME"  - is the name of the option do not change it.
-- "="            - is the required keyword do not change it.
-- "OPTION_VALUE" - the value of the option you can change it to the one of the listed in the option comment.
-- " ;"           - is the required keyword do not change it.
-- "-- OPTION COMMENT" - do not change it.
--
-- ### END READ ME FIRST ### NEXT ARE ACTUAL MOD OPTIONS:

Mod_RMT_Transparent_Background = false ; -- Use false or true value here.

Mod_RMT_Window_Position   = 2 ; -- Use 1 for LEFT; 2 for CENTER; 3 for RIGHT.
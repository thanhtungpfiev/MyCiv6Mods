-- ===========================================================================
-- Base File
-- ===========================================================================
include("PartialScreenHooks_Expansion2");

include("partialscreenhooks_CQUI.lua");
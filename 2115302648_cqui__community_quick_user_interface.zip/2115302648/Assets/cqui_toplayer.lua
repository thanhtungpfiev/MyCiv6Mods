--This is a layer that lives at the very top of the UI. It's an excellent place for catching inputs globally or displaying a custom overlay

function Initialize()
    ContextPtr:SetHide(false);
end

Initialize();

-- ===========================================================================
-- Base File
-- ===========================================================================
include("DiplomacyActionView_Expansion1.lua");

include("diplomacyactionview_CQUI.lua");
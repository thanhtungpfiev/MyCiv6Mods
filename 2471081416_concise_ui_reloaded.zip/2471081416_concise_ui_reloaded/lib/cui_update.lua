CuiVersion = "1.8.1"
LastUpdate = "2021-05-04"
VersionDetail = "Concise UI Reloaded - " .. CuiVersion .. "[NEWLINE]" .. "Last Update: " .. LastUpdate
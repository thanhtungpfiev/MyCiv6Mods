-- ===========================================================================
-- Better Civilopedia
-- Author: Infixo
-- 2018-03-23: Created
-- ===========================================================================

-- just to make versioning easier
INSERT INTO GlobalParameters (Name, Value) VALUES ('BCP_VERSION_MAJOR', '2');
INSERT INTO GlobalParameters (Name, Value) VALUES ('BCP_VERSION_MINOR', '2');

-- options
INSERT INTO GlobalParameters (Name, Value) VALUES ('BCP_OPTION_MODIFIERS', '1');
INSERT INTO GlobalParameters (Name, Value) VALUES ('BCP_OPTION_AILISTS',   '1');
INSERT INTO GlobalParameters (Name, Value) VALUES ('BCP_OPTION_INTERNAL',  '0');

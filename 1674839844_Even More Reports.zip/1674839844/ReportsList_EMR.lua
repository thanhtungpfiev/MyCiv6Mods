-- ===========================================================================
--	Even More Reports: ReportsList
--  Author: Faronizer
-- ===========================================================================
local bRiseFall:boolean = Modding.IsModActive("1B28771A-C749-434B-9053-D1380C553DE9"); -- Rise & Fall
local bGatheringStorm:boolean = Modding.IsModActive("4873eb62-8ccc-4574-b784-dda455e74e68"); -- Gathering Storm
local bBetterReportScreen:boolean = Modding.IsModActive("6f2888d4-79dc-415f-a8ff-f9d81d7afb53"); -- Better Report Screen

if bBetterReportScreen then 
    include("ReportsList_BRS")
else
    include("ReportsList")
end

local function ContextualClose()
    -- only Better Report Screen closes the ReportsList Panel
    if bBetterReportScreen then Close() end
end

function OnRaiseDemographicsReport() ContextualClose(); LuaEvents.ReportsList_OpenDemographics(); end
function OnRaiseGraphsReport() ContextualClose(); LuaEvents.ReportsList_OpenGraphs(); end

function InjectReports()
    AddReport("Demographics", OnRaiseDemographicsReport, Controls.GlobalReportsStack);
    AddReport("Graphs", OnRaiseGraphsReport, Controls.GlobalReportsStack);
    Controls.GlobalTitle:SetHide(false);
end

-- be late to the party
Events.LoadGameViewStateDone.Add(InjectReports);
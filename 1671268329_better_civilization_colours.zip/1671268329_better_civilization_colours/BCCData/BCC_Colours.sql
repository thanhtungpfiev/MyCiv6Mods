-- BCC_ColoursLite
-- Author: janboruta
-- DateCreated: 2/28/2019 5:21:54 PM
--------------------------------------------------------------

--------------------------------------------------------------
-- New Colours --
--------------------------------------------------------------
INSERT OR REPLACE INTO Colors 
	(Type,								Color)
VALUES	
	('COLOR_STANDARD_IMPERIAL_LT',		"250,150,170,255"),
	('COLOR_STANDARD_IMPERIAL_MD',		"195,0,75,255"),
	('COLOR_STANDARD_IMPERIAL_DK',		"135,0,60,255"),
	
	('COLOR_STANDARD_INDIGO_LT',		"170,235,235,255"),
	('COLOR_STANDARD_INDIGO_MD',		"0,125,175,255"),
	('COLOR_STANDARD_INDIGO_DK',		"0,70,90,255"),
	
	('COLOR_STANDARD_LIME_LT',			"195,215,30,255"),
	('COLOR_STANDARD_LIME_MD',			"125,165,5,255"),
	('COLOR_STANDARD_LIME_DK',			"75,95,0,255"),
	
	('COLOR_STANDARD_SAND_LT',			"210,200,160,255"),
	('COLOR_STANDARD_SAND_MD',			"170,140,60,255"),
	('COLOR_STANDARD_SAND_DK',			"70,50,25,255"),
	
	('COLOR_STANDARD_WHITE_MD3',		"120,120,120,255");

--------------------------------------------------------------
-- Updated Vanilla Colours --
--------------------------------------------------------------

-- Aqua ------------------------------------------------------
UPDATE Colors
SET Color = "140,230,185,255"
WHERE Type = 'COLOR_STANDARD_AQUA_LT';

UPDATE Colors
SET Color = "50,220,175,255"
WHERE Type = 'COLOR_STANDARD_AQUA_MD';

UPDATE Colors
SET Color = "5,95,75,255"
WHERE Type = 'COLOR_STANDARD_AQUA_DK';

-- Blue ------------------------------------------------------
UPDATE Colors
SET Color = "150,195,235,255"
WHERE Type = 'COLOR_STANDARD_BLUE_LT';

UPDATE Colors
SET Color = "0,80,205,255"
WHERE Type = 'COLOR_STANDARD_BLUE_MD';

UPDATE Colors
SET Color = "0,45,100,255"
WHERE Type = 'COLOR_STANDARD_BLUE_DK';

-- Green -----------------------------------------------------
UPDATE Colors
SET Color = "110,200,110,255"
WHERE Type = 'COLOR_STANDARD_GREEN_LT';

UPDATE Colors
SET Color = "20,130,50,255"
WHERE Type = 'COLOR_STANDARD_GREEN_MD';

UPDATE Colors
SET Color = "5,70,25,255"
WHERE Type = 'COLOR_STANDARD_GREEN_DK';

-- Magenta --------------------------------------------------
UPDATE Colors
SET Color = "255,155,200,255"
WHERE Type = 'COLOR_STANDARD_MAGENTA_LT';

UPDATE Colors
SET Color = "255,0,255,255"
WHERE Type = 'COLOR_STANDARD_MAGENTA_MD';

UPDATE Colors
SET Color = "125,0,125,255"
WHERE Type = 'COLOR_STANDARD_MAGENTA_DK';

-- Orange ---------------------------------------------------
UPDATE Colors
SET Color = "255,185,70,255"
WHERE Type = 'COLOR_STANDARD_ORANGE_LT';

UPDATE Colors
SET Color = "255,140,40,255"
WHERE Type = 'COLOR_STANDARD_ORANGE_MD';

UPDATE Colors
SET Color = "120,55,0,255"
WHERE Type = 'COLOR_STANDARD_ORANGE_DK';

-- Purple ---------------------------------------------------
UPDATE Colors
SET Color = "210,135,210,255"
WHERE Type = 'COLOR_STANDARD_PURPLE_LT';

UPDATE Colors
SET Color = "110,60,170,255"
WHERE Type = 'COLOR_STANDARD_PURPLE_MD';

UPDATE Colors
SET Color = "70,20,110,255"
WHERE Type = 'COLOR_STANDARD_PURPLE_DK';

-- Red ------------------------------------------------------
UPDATE Colors
SET Color = "240,95,95,255"
WHERE Type = 'COLOR_STANDARD_RED_LT';

UPDATE Colors
SET Color = "200,20,20,255"
WHERE Type = 'COLOR_STANDARD_RED_MD';

UPDATE Colors
SET Color = "140,5,5,255"
WHERE Type = 'COLOR_STANDARD_RED_DK';

-- Yellow ---------------------------------------------------
UPDATE Colors
SET Color = "235,235,155,255"
WHERE Type = 'COLOR_STANDARD_YELLOW_LT';

UPDATE Colors
SET Color = "245,215,0,255"
WHERE Type = 'COLOR_STANDARD_YELLOW_MD';

UPDATE Colors
SET Color = "120,90,0,255"
WHERE Type = 'COLOR_STANDARD_YELLOW_DK';

-- White ----------------------------------------------------
UPDATE Colors
SET Color = "250,250,250,255"
WHERE Type = 'COLOR_STANDARD_WHITE_LT';

UPDATE Colors
SET Color = "60,60,60,255"
WHERE Type = 'COLOR_STANDARD_WHITE_MD';

UPDATE Colors
SET Color = "200,200,200,255"
WHERE Type = 'COLOR_STANDARD_WHITE_MD2';

UPDATE Colors
SET Color = "20,20,20,255"
WHERE Type = 'COLOR_STANDARD_WHITE_DK';
--------------------------------------------------------------
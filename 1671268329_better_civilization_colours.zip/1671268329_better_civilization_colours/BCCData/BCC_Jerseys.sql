-- BCC_JerseysLite
-- Author: janboruta
-- DateCreated: 2/28/2019 5:24:01 PM
--------------------------------------------------------------

--------------------------------------------------------------
-- America --
--------------------------------------------------------------

-- Roosevelt - Bull Moose --

UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_BLUE_DK"
WHERE Type = 'LEADER_T_ROOSEVELT';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'LEADER_T_ROOSEVELT';

UPDATE PlayerColors
SET Alt1PrimaryColor = "COLOR_STANDARD_BLUE_MD"
WHERE Type = 'LEADER_T_ROOSEVELT';

UPDATE PlayerColors
SET Alt1SecondaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'LEADER_T_ROOSEVELT';

UPDATE PlayerColors
SET Alt2PrimaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'LEADER_T_ROOSEVELT';

UPDATE PlayerColors
SET Alt2SecondaryColor = "COLOR_STANDARD_BLUE_DK"
WHERE Type = 'LEADER_T_ROOSEVELT';

UPDATE PlayerColors
SET Alt3PrimaryColor = "COLOR_STANDARD_RED_MD"
WHERE Type = 'LEADER_T_ROOSEVELT';

UPDATE PlayerColors
SET Alt3SecondaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'LEADER_T_ROOSEVELT';

-- Roosevelt - Rough Rider --

UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_BLUE_MD"
WHERE Type = 'LEADER_T_ROOSEVELT_ROUGHRIDER';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'LEADER_T_ROOSEVELT_ROUGHRIDER';

UPDATE PlayerColors
SET Alt1PrimaryColor = "COLOR_STANDARD_BLUE_DK"
WHERE Type = 'LEADER_T_ROOSEVELT_ROUGHRIDER';

UPDATE PlayerColors
SET Alt1SecondaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'LEADER_T_ROOSEVELT_ROUGHRIDER';

UPDATE PlayerColors
SET Alt2PrimaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'LEADER_T_ROOSEVELT_ROUGHRIDER';

UPDATE PlayerColors
SET Alt2SecondaryColor = "COLOR_STANDARD_BLUE_DK"
WHERE Type = 'LEADER_T_ROOSEVELT_ROUGHRIDER';

UPDATE PlayerColors
SET Alt3PrimaryColor = "COLOR_STANDARD_RED_MD"
WHERE Type = 'LEADER_T_ROOSEVELT_ROUGHRIDER';

UPDATE PlayerColors
SET Alt3SecondaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'LEADER_T_ROOSEVELT_ROUGHRIDER';

-- Lincoln --

UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'LEADER_ABRAHAM_LINCOLN';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_BLUE_DK"
WHERE Type = 'LEADER_ABRAHAM_LINCOLN';

UPDATE PlayerColors
SET Alt1PrimaryColor = "COLOR_STANDARD_BLUE_DK"
WHERE Type = 'LEADER_ABRAHAM_LINCOLN';

UPDATE PlayerColors
SET Alt1SecondaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'LEADER_ABRAHAM_LINCOLN';

UPDATE PlayerColors
SET Alt2PrimaryColor = "COLOR_STANDARD_BLUE_MD"
WHERE Type = 'LEADER_ABRAHAM_LINCOLN';

UPDATE PlayerColors
SET Alt2SecondaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'LEADER_ABRAHAM_LINCOLN';

UPDATE PlayerColors
SET Alt3PrimaryColor = "COLOR_STANDARD_RED_MD"
WHERE Type = 'LEADER_ABRAHAM_LINCOLN';

UPDATE PlayerColors
SET Alt3SecondaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'LEADER_ABRAHAM_LINCOLN';

--------------------------------------------------------------
-- Arabia --
--------------------------------------------------------------

-- Saladin - Vizier --

UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_YELLOW_MD"
WHERE Type = 'LEADER_SALADIN';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_GREEN_DK"
WHERE Type = 'LEADER_SALADIN';

UPDATE PlayerColors
SET Alt1PrimaryColor = "COLOR_STANDARD_GREEN_DK"
WHERE Type = 'LEADER_SALADIN';

UPDATE PlayerColors
SET Alt1SecondaryColor = "COLOR_STANDARD_LIME_LT"
WHERE Type = 'LEADER_SALADIN';

UPDATE PlayerColors
SET Alt2PrimaryColor = "COLOR_STANDARD_GREEN_MD"
WHERE Type = 'LEADER_SALADIN';

UPDATE PlayerColors
SET Alt2SecondaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'LEADER_SALADIN';

UPDATE PlayerColors
SET Alt3PrimaryColor = "COLOR_STANDARD_YELLOW_LT"
WHERE Type = 'LEADER_SALADIN';

UPDATE PlayerColors
SET Alt3SecondaryColor = "COLOR_STANDARD_SAND_DK"
WHERE Type = 'LEADER_SALADIN';

-- Saladin - Sultan --

UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_GREEN_DK"
WHERE Type = 'LEADER_SALADIN_ALT';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_LIME_LT"
WHERE Type = 'LEADER_SALADIN_ALT';

UPDATE PlayerColors
SET Alt1PrimaryColor = "COLOR_STANDARD_GREEN_MD"
WHERE Type = 'LEADER_SALADIN_ALT';

UPDATE PlayerColors
SET Alt1SecondaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'LEADER_SALADIN_ALT';

UPDATE PlayerColors
SET Alt2PrimaryColor = "COLOR_STANDARD_YELLOW_DK"
WHERE Type = 'LEADER_SALADIN_ALT';

UPDATE PlayerColors
SET Alt2SecondaryColor = "COLOR_STANDARD_YELLOW_LT"
WHERE Type = 'LEADER_SALADIN_ALT';

UPDATE PlayerColors
SET Alt3PrimaryColor = "COLOR_STANDARD_YELLOW_LT"
WHERE Type = 'LEADER_SALADIN_ALT';

UPDATE PlayerColors
SET Alt3SecondaryColor = "COLOR_STANDARD_SAND_DK"
WHERE Type = 'LEADER_SALADIN_ALT';

--------------------------------------------------------------
-- Australia --
--------------------------------------------------------------
UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_AQUA_DK"
WHERE Type = 'LEADER_JOHN_CURTIN';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_YELLOW_MD"
WHERE Type = 'LEADER_JOHN_CURTIN';

UPDATE PlayerColors
SET Alt1PrimaryColor = "COLOR_STANDARD_YELLOW_MD"
WHERE Type = 'LEADER_JOHN_CURTIN';

UPDATE PlayerColors
SET Alt1SecondaryColor = "COLOR_STANDARD_AQUA_DK"
WHERE Type = 'LEADER_JOHN_CURTIN';

UPDATE PlayerColors
SET Alt2PrimaryColor = "COLOR_STANDARD_BLUE_DK"
WHERE Type = 'LEADER_JOHN_CURTIN';

UPDATE PlayerColors
SET Alt2SecondaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'LEADER_JOHN_CURTIN';

UPDATE PlayerColors
SET Alt3PrimaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'LEADER_JOHN_CURTIN';

UPDATE PlayerColors
SET Alt3SecondaryColor = "COLOR_STANDARD_BLUE_DK"
WHERE Type = 'LEADER_JOHN_CURTIN';

--------------------------------------------------------------
-- Aztec --
--------------------------------------------------------------
UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_AQUA_LT"
WHERE Type = 'LEADER_MONTEZUMA';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_RED_DK"
WHERE Type = 'LEADER_MONTEZUMA';

UPDATE PlayerColors
SET Alt1PrimaryColor = "COLOR_STANDARD_RED_DK"
WHERE Type = 'LEADER_MONTEZUMA';

UPDATE PlayerColors
SET Alt1SecondaryColor = "COLOR_STANDARD_AQUA_LT"
WHERE Type = 'LEADER_MONTEZUMA';

UPDATE PlayerColors
SET Alt2PrimaryColor = "COLOR_STANDARD_AQUA_DK"
WHERE Type = 'LEADER_MONTEZUMA';

UPDATE PlayerColors
SET Alt2SecondaryColor = "COLOR_STANDARD_AQUA_LT"
WHERE Type = 'LEADER_MONTEZUMA';

UPDATE PlayerColors
SET Alt3PrimaryColor = "COLOR_STANDARD_RED_MD"
WHERE Type = 'LEADER_MONTEZUMA';

UPDATE PlayerColors
SET Alt3SecondaryColor = "COLOR_STANDARD_AQUA_LT"
WHERE Type = 'LEADER_MONTEZUMA';

--------------------------------------------------------------
-- Babylon --
--------------------------------------------------------------
UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_INDIGO_DK"
WHERE Type = 'LEADER_HAMMURABI';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_INDIGO_LT"
WHERE Type = 'LEADER_HAMMURABI';

UPDATE PlayerColors
SET Alt1PrimaryColor = "COLOR_STANDARD_INDIGO_LT"
WHERE Type = 'LEADER_HAMMURABI';

UPDATE PlayerColors
SET Alt1SecondaryColor = "COLOR_STANDARD_INDIGO_DK"
WHERE Type = 'LEADER_HAMMURABI';

UPDATE PlayerColors
SET Alt2PrimaryColor = "COLOR_STANDARD_MAGENTA_DK"
WHERE Type = 'LEADER_HAMMURABI';

UPDATE PlayerColors
SET Alt2SecondaryColor = "COLOR_STANDARD_YELLOW_MD"
WHERE Type = 'LEADER_HAMMURABI';

UPDATE PlayerColors
SET Alt3PrimaryColor = "COLOR_STANDARD_YELLOW_MD"
WHERE Type = 'LEADER_HAMMURABI';

UPDATE PlayerColors
SET Alt3SecondaryColor = "COLOR_STANDARD_MAGENTA_DK"
WHERE Type = 'LEADER_HAMMURABI';

--------------------------------------------------------------
-- Brazil --
--------------------------------------------------------------
UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_GREEN_MD"
WHERE Type = 'LEADER_PEDRO';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_YELLOW_MD"
WHERE Type = 'LEADER_PEDRO';

UPDATE PlayerColors
SET Alt1PrimaryColor = "COLOR_STANDARD_GREEN_DK"
WHERE Type = 'LEADER_PEDRO';

UPDATE PlayerColors
SET Alt1SecondaryColor = "COLOR_STANDARD_LIME_LT"
WHERE Type = 'LEADER_PEDRO';

UPDATE PlayerColors
SET Alt2PrimaryColor = "COLOR_STANDARD_LIME_LT"
WHERE Type = 'LEADER_PEDRO';

UPDATE PlayerColors
SET Alt2SecondaryColor = "COLOR_STANDARD_GREEN_DK"
WHERE Type = 'LEADER_PEDRO';

UPDATE PlayerColors
SET Alt3PrimaryColor = "COLOR_STANDARD_BLUE_DK"
WHERE Type = 'LEADER_PEDRO';

UPDATE PlayerColors
SET Alt3SecondaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'LEADER_PEDRO';

--------------------------------------------------------------
-- Byzantium --
--------------------------------------------------------------

-- Basil --

UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_PURPLE_DK"
WHERE Type = 'LEADER_BASIL';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_YELLOW_LT"
WHERE Type = 'LEADER_BASIL';

UPDATE PlayerColors
SET Alt1PrimaryColor = "COLOR_STANDARD_BLUE_LT"
WHERE Type = 'LEADER_BASIL';

UPDATE PlayerColors
SET Alt1SecondaryColor = "COLOR_STANDARD_PURPLE_DK"
WHERE Type = 'LEADER_BASIL';

UPDATE PlayerColors
SET Alt2PrimaryColor = "COLOR_STANDARD_MAGENTA_DK"
WHERE Type = 'LEADER_BASIL';

UPDATE PlayerColors
SET Alt2SecondaryColor = "COLOR_STANDARD_YELLOW_MD"
WHERE Type = 'LEADER_BASIL';

UPDATE PlayerColors
SET Alt3PrimaryColor = "COLOR_STANDARD_ORANGE_LT"
WHERE Type = 'LEADER_BASIL';

UPDATE PlayerColors
SET Alt3SecondaryColor = "COLOR_STANDARD_PURPLE_DK"
WHERE Type = 'LEADER_BASIL';

-- Theodora --

UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_MAGENTA_DK"
WHERE Type = 'LEADER_THEODORA';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_YELLOW_MD"
WHERE Type = 'LEADER_THEODORA';

UPDATE PlayerColors
SET Alt1PrimaryColor = "COLOR_STANDARD_YELLOW_MD"
WHERE Type = 'LEADER_THEODORA';

UPDATE PlayerColors
SET Alt1SecondaryColor = "COLOR_STANDARD_MAGENTA_DK"
WHERE Type = 'LEADER_THEODORA';

UPDATE PlayerColors
SET Alt2PrimaryColor = "COLOR_STANDARD_BLUE_LT"
WHERE Type = 'LEADER_THEODORA';

UPDATE PlayerColors
SET Alt2SecondaryColor = "COLOR_STANDARD_PURPLE_DK"
WHERE Type = 'LEADER_THEODORA';

UPDATE PlayerColors
SET Alt3PrimaryColor = "COLOR_STANDARD_PURPLE_DK"
WHERE Type = 'LEADER_THEODORA';

UPDATE PlayerColors
SET Alt3SecondaryColor = "COLOR_STANDARD_BLUE_LT"
WHERE Type = 'LEADER_THEODORA';

--------------------------------------------------------------
-- Canada --
--------------------------------------------------------------
UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'LEADER_LAURIER';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_RED_MD"
WHERE Type = 'LEADER_LAURIER';

UPDATE PlayerColors
SET Alt1PrimaryColor = "COLOR_STANDARD_RED_MD"
WHERE Type = 'LEADER_LAURIER';

UPDATE PlayerColors
SET Alt1SecondaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'LEADER_LAURIER';

UPDATE PlayerColors
SET Alt2PrimaryColor = "COLOR_STANDARD_BLUE_MD"
WHERE Type = 'LEADER_LAURIER';

UPDATE PlayerColors
SET Alt2SecondaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'LEADER_LAURIER';

UPDATE PlayerColors
SET Alt3PrimaryColor = "COLOR_STANDARD_GREEN_DK"
WHERE Type = 'LEADER_LAURIER';

UPDATE PlayerColors
SET Alt3SecondaryColor = "COLOR_STANDARD_YELLOW_MD"
WHERE Type = 'LEADER_LAURIER';

--------------------------------------------------------------
-- China --
--------------------------------------------------------------

-- Qin - Mandate of Heaven --

UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_AQUA_DK"
WHERE Type = 'LEADER_QIN';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'LEADER_QIN';

UPDATE PlayerColors
SET Alt1PrimaryColor = "COLOR_STANDARD_GREEN_MD"
WHERE Type = 'LEADER_QIN';

UPDATE PlayerColors
SET Alt1SecondaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'LEADER_QIN';

UPDATE PlayerColors
SET Alt2PrimaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'LEADER_QIN';

UPDATE PlayerColors
SET Alt2SecondaryColor = "COLOR_STANDARD_AQUA_DK"
WHERE Type = 'LEADER_QIN';

UPDATE PlayerColors
SET Alt3PrimaryColor = "COLOR_STANDARD_IMPERIAL_DK"
WHERE Type = 'LEADER_QIN';

UPDATE PlayerColors
SET Alt3SecondaryColor = "COLOR_STANDARD_YELLOW_MD"
WHERE Type = 'LEADER_QIN';

-- Qin - Unifier --

UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'LEADER_QIN_ALT';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_AQUA_DK"
WHERE Type = 'LEADER_QIN_ALT';

UPDATE PlayerColors
SET Alt1PrimaryColor = "COLOR_STANDARD_AQUA_DK"
WHERE Type = 'LEADER_QIN_ALT';

UPDATE PlayerColors
SET Alt1SecondaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'LEADER_QIN_ALT';

UPDATE PlayerColors
SET Alt2PrimaryColor = "COLOR_STANDARD_GREEN_MD"
WHERE Type = 'LEADER_QIN_ALT';

UPDATE PlayerColors
SET Alt2SecondaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'LEADER_QIN_ALT';

UPDATE PlayerColors
SET Alt3PrimaryColor = "COLOR_STANDARD_IMPERIAL_DK"
WHERE Type = 'LEADER_QIN_ALT';

UPDATE PlayerColors
SET Alt3SecondaryColor = "COLOR_STANDARD_YELLOW_MD"
WHERE Type = 'LEADER_QIN_ALT';

-- Kublai --

UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_YELLOW_LT"
WHERE Type = 'LEADER_KUBLAI_KHAN_CHINA';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_IMPERIAL_DK"
WHERE Type = 'LEADER_KUBLAI_KHAN_CHINA';

UPDATE PlayerColors
SET Alt1PrimaryColor = "COLOR_STANDARD_IMPERIAL_DK"
WHERE Type = 'LEADER_KUBLAI_KHAN_CHINA';

UPDATE PlayerColors
SET Alt1SecondaryColor = "COLOR_STANDARD_YELLOW_LT"
WHERE Type = 'LEADER_KUBLAI_KHAN_CHINA';

UPDATE PlayerColors
SET Alt2PrimaryColor = "COLOR_STANDARD_AQUA_DK"
WHERE Type = 'LEADER_KUBLAI_KHAN_CHINA';

UPDATE PlayerColors
SET Alt2SecondaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'LEADER_KUBLAI_KHAN_CHINA';

UPDATE PlayerColors
SET Alt3PrimaryColor = "COLOR_STANDARD_INDIGO_LT"
WHERE Type = 'LEADER_KUBLAI_KHAN_CHINA';

UPDATE PlayerColors
SET Alt3SecondaryColor = "COLOR_STANDARD_INDIGO_DK"
WHERE Type = 'LEADER_KUBLAI_KHAN_CHINA';

-- Yongle --

UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_YELLOW_MD"
WHERE Type = 'LEADER_YONGLE';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_INDIGO_DK"
WHERE Type = 'LEADER_YONGLE';

UPDATE PlayerColors
SET Alt1PrimaryColor = "COLOR_STANDARD_YELLOW_LT"
WHERE Type = 'LEADER_YONGLE';

UPDATE PlayerColors
SET Alt1SecondaryColor = "COLOR_STANDARD_INDIGO_DK"
WHERE Type = 'LEADER_YONGLE';

UPDATE PlayerColors
SET Alt2PrimaryColor = "COLOR_STANDARD_AQUA_DK"
WHERE Type = 'LEADER_YONGLE';

UPDATE PlayerColors
SET Alt2SecondaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'LEADER_YONGLE';

UPDATE PlayerColors
SET Alt3PrimaryColor = "COLOR_STANDARD_IMPERIAL_DK"
WHERE Type = 'LEADER_YONGLE';

UPDATE PlayerColors
SET Alt3SecondaryColor = "COLOR_STANDARD_YELLOW_MD"
WHERE Type = 'LEADER_YONGLE';

-- Wu Zetian --

UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_IMPERIAL_DK"
WHERE Type = 'LEADER_WU_ZETIAN';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_YELLOW_MD"
WHERE Type = 'LEADER_WU_ZETIAN';

UPDATE PlayerColors
SET Alt1PrimaryColor = "COLOR_STANDARD_YELLOW_MD"
WHERE Type = 'LEADER_WU_ZETIAN';

UPDATE PlayerColors
SET Alt1SecondaryColor = "COLOR_STANDARD_IMPERIAL_DK"
WHERE Type = 'LEADER_WU_ZETIAN';

UPDATE PlayerColors
SET Alt2PrimaryColor = "COLOR_STANDARD_AQUA_DK"
WHERE Type = 'LEADER_WU_ZETIAN';

UPDATE PlayerColors
SET Alt2SecondaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'LEADER_WU_ZETIAN';

UPDATE PlayerColors
SET Alt3PrimaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'LEADER_WU_ZETIAN';

UPDATE PlayerColors
SET Alt3SecondaryColor = "COLOR_STANDARD_AQUA_DK"
WHERE Type = 'LEADER_WU_ZETIAN';

--------------------------------------------------------------
-- Colombia --
--------------------------------------------------------------
UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_BLUE_DK"
WHERE Type = 'LEADER_SIMON_BOLIVAR';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_YELLOW_MD"
WHERE Type = 'LEADER_SIMON_BOLIVAR';

UPDATE PlayerColors
SET Alt1PrimaryColor = "COLOR_STANDARD_YELLOW_MD"
WHERE Type = 'LEADER_SIMON_BOLIVAR';

UPDATE PlayerColors
SET Alt1SecondaryColor = "COLOR_STANDARD_BLUE_DK"
WHERE Type = 'LEADER_SIMON_BOLIVAR';

UPDATE PlayerColors
SET Alt2PrimaryColor = "COLOR_STANDARD_RED_DK"
WHERE Type = 'LEADER_SIMON_BOLIVAR';

UPDATE PlayerColors
SET Alt2SecondaryColor = "COLOR_STANDARD_ORANGE_LT"
WHERE Type = 'LEADER_SIMON_BOLIVAR';

UPDATE PlayerColors
SET Alt3PrimaryColor = "COLOR_STANDARD_BLUE_MD"
WHERE Type = 'LEADER_SIMON_BOLIVAR';

UPDATE PlayerColors
SET Alt3SecondaryColor = "COLOR_STANDARD_INDIGO_LT"
WHERE Type = 'LEADER_SIMON_BOLIVAR';

--------------------------------------------------------------
-- Cree --
--------------------------------------------------------------
UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_BLUE_DK"
WHERE Type = 'LEADER_POUNDMAKER';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_GREEN_LT"
WHERE Type = 'LEADER_POUNDMAKER';

UPDATE PlayerColors
SET Alt1PrimaryColor = "COLOR_STANDARD_BLUE_LT"
WHERE Type = 'LEADER_POUNDMAKER';

UPDATE PlayerColors
SET Alt1SecondaryColor = "COLOR_STANDARD_GREEN_DK"
WHERE Type = 'LEADER_POUNDMAKER';

UPDATE PlayerColors
SET Alt2PrimaryColor = "COLOR_STANDARD_AQUA_DK"
WHERE Type = 'LEADER_POUNDMAKER';

UPDATE PlayerColors
SET Alt2SecondaryColor = "COLOR_STANDARD_YELLOW_LT"
WHERE Type = 'LEADER_POUNDMAKER';

UPDATE PlayerColors
SET Alt3PrimaryColor = "COLOR_STANDARD_RED_MD"
WHERE Type = 'LEADER_POUNDMAKER';

UPDATE PlayerColors
SET Alt3SecondaryColor = "COLOR_STANDARD_AQUA_LT"
WHERE Type = 'LEADER_POUNDMAKER';

--------------------------------------------------------------
-- Egypt --
--------------------------------------------------------------

-- Cleopatra - Egyptian --

UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_AQUA_DK"
WHERE Type = 'LEADER_CLEOPATRA';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_YELLOW_LT"
WHERE Type = 'LEADER_CLEOPATRA';

UPDATE PlayerColors
SET Alt1PrimaryColor = "COLOR_STANDARD_YELLOW_LT"
WHERE Type = 'LEADER_CLEOPATRA';

UPDATE PlayerColors
SET Alt1SecondaryColor = "COLOR_STANDARD_AQUA_DK"
WHERE Type = 'LEADER_CLEOPATRA';

UPDATE PlayerColors
SET Alt2PrimaryColor = "COLOR_STANDARD_MAGENTA_DK"
WHERE Type = 'LEADER_CLEOPATRA';

UPDATE PlayerColors
SET Alt2SecondaryColor = "COLOR_STANDARD_YELLOW_MD"
WHERE Type = 'LEADER_CLEOPATRA';

UPDATE PlayerColors
SET Alt3PrimaryColor = "COLOR_STANDARD_YELLOW_MD"
WHERE Type = 'LEADER_CLEOPATRA';

UPDATE PlayerColors
SET Alt3SecondaryColor = "COLOR_STANDARD_MAGENTA_DK"
WHERE Type = 'LEADER_CLEOPATRA';

-- Cleopatra - Ptolemaic --

UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_YELLOW_LT"
WHERE Type = 'LEADER_CLEOPATRA_ALT';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_AQUA_DK"
WHERE Type = 'LEADER_CLEOPATRA_ALT';

UPDATE PlayerColors
SET Alt1PrimaryColor = "COLOR_STANDARD_AQUA_DK"
WHERE Type = 'LEADER_CLEOPATRA_ALT';

UPDATE PlayerColors
SET Alt1SecondaryColor = "COLOR_STANDARD_YELLOW_LT"
WHERE Type = 'LEADER_CLEOPATRA_ALT';

UPDATE PlayerColors
SET Alt2PrimaryColor = "COLOR_STANDARD_INDIGO_MD"
WHERE Type = 'LEADER_CLEOPATRA_ALT';

UPDATE PlayerColors
SET Alt2SecondaryColor = "COLOR_STANDARD_YELLOW_MD"
WHERE Type = 'LEADER_CLEOPATRA_ALT';

UPDATE PlayerColors
SET Alt3PrimaryColor = "COLOR_STANDARD_YELLOW_MD"
WHERE Type = 'LEADER_CLEOPATRA_ALT';

UPDATE PlayerColors
SET Alt3SecondaryColor = "COLOR_STANDARD_INDIGO_MD"
WHERE Type = 'LEADER_CLEOPATRA_ALT';

-- Ramses --

UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_YELLOW_MD"
WHERE Type = 'LEADER_RAMSES';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_PURPLE_MD"
WHERE Type = 'LEADER_RAMSES';

UPDATE PlayerColors
SET Alt1PrimaryColor = "COLOR_STANDARD_PURPLE_MD"
WHERE Type = 'LEADER_RAMSES';

UPDATE PlayerColors
SET Alt1SecondaryColor = "COLOR_STANDARD_YELLOW_MD"
WHERE Type = 'LEADER_RAMSES';

UPDATE PlayerColors
SET Alt2PrimaryColor = "COLOR_STANDARD_YELLOW_LT"
WHERE Type = 'LEADER_RAMSES';

UPDATE PlayerColors
SET Alt2SecondaryColor = "COLOR_STANDARD_PURPLE_MD"
WHERE Type = 'LEADER_RAMSES';

UPDATE PlayerColors
SET Alt3PrimaryColor = "COLOR_STANDARD_YELLOW_DK"
WHERE Type = 'LEADER_RAMSES';

UPDATE PlayerColors
SET Alt3SecondaryColor = "COLOR_STANDARD_YELLOW_LT"
WHERE Type = 'LEADER_RAMSES';

--------------------------------------------------------------
-- Eleanor --
--------------------------------------------------------------

-- England --

UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_RED_LT"
WHERE Type = 'LEADER_ELEANOR_ENGLAND';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'LEADER_ELEANOR_ENGLAND';

UPDATE PlayerColors
SET Alt1PrimaryColor = "COLOR_STANDARD_RED_MD"
WHERE Type = 'LEADER_ELEANOR_ENGLAND';

UPDATE PlayerColors
SET Alt1SecondaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'LEADER_ELEANOR_ENGLAND';

UPDATE PlayerColors
SET Alt2PrimaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'LEADER_ELEANOR_ENGLAND';

UPDATE PlayerColors
SET Alt2SecondaryColor = "COLOR_STANDARD_RED_MD"
WHERE Type = 'LEADER_ELEANOR_ENGLAND';

UPDATE PlayerColors
SET Alt3PrimaryColor = "COLOR_STANDARD_PURPLE_MD"
WHERE Type = 'LEADER_ELEANOR_ENGLAND';

UPDATE PlayerColors
SET Alt3SecondaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'LEADER_ELEANOR_ENGLAND';

-- France --

UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_RED_LT"
WHERE Type = 'LEADER_ELEANOR_FRANCE';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_YELLOW_LT"
WHERE Type = 'LEADER_ELEANOR_FRANCE';

UPDATE PlayerColors
SET Alt1PrimaryColor = "COLOR_STANDARD_BLUE_MD"
WHERE Type = 'LEADER_ELEANOR_FRANCE';

UPDATE PlayerColors
SET Alt1SecondaryColor = "COLOR_STANDARD_YELLOW_LT"
WHERE Type = 'LEADER_ELEANOR_FRANCE';

UPDATE PlayerColors
SET Alt2PrimaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'LEADER_ELEANOR_FRANCE';

UPDATE PlayerColors
SET Alt2SecondaryColor = "COLOR_STANDARD_YELLOW_DK"
WHERE Type = 'LEADER_ELEANOR_FRANCE';

UPDATE PlayerColors
SET Alt3PrimaryColor = "COLOR_STANDARD_PURPLE_MD"
WHERE Type = 'LEADER_ELEANOR_FRANCE';

UPDATE PlayerColors
SET Alt3SecondaryColor = "COLOR_STANDARD_YELLOW_LT"
WHERE Type = 'LEADER_ELEANOR_FRANCE';

--------------------------------------------------------------
-- England --
--------------------------------------------------------------

-- Victoria - Age of Empire --

UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_RED_DK"
WHERE Type = 'LEADER_VICTORIA';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'LEADER_VICTORIA';

UPDATE PlayerColors
SET Alt1PrimaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'LEADER_VICTORIA';

UPDATE PlayerColors
SET Alt1SecondaryColor = "COLOR_STANDARD_RED_DK"
WHERE Type = 'LEADER_VICTORIA';

UPDATE PlayerColors
SET Alt2PrimaryColor = "COLOR_STANDARD_BLUE_DK"
WHERE Type = 'LEADER_VICTORIA';

UPDATE PlayerColors
SET Alt2SecondaryColor = "COLOR_STANDARD_RED_MD"
WHERE Type = 'LEADER_VICTORIA';

UPDATE PlayerColors
SET Alt3PrimaryColor = "COLOR_STANDARD_BLUE_LT"
WHERE Type = 'LEADER_VICTORIA';

UPDATE PlayerColors
SET Alt3SecondaryColor = "COLOR_STANDARD_RED_DK"
WHERE Type = 'LEADER_VICTORIA';

-- Victoria - Age of Steam --

UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_RED_MD"
WHERE Type = 'LEADER_VICTORIA_ALT';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'LEADER_VICTORIA_ALT';

UPDATE PlayerColors
SET Alt1PrimaryColor = "COLOR_STANDARD_BLUE_DK"
WHERE Type = 'LEADER_VICTORIA_ALT';

UPDATE PlayerColors
SET Alt1SecondaryColor = "COLOR_STANDARD_RED_MD"
WHERE Type = 'LEADER_VICTORIA_ALT';

UPDATE PlayerColors
SET Alt2PrimaryColor = "COLOR_STANDARD_BLUE_LT"
WHERE Type = 'LEADER_VICTORIA_ALT';

UPDATE PlayerColors
SET Alt2SecondaryColor = "COLOR_STANDARD_RED_DK"
WHERE Type = 'LEADER_VICTORIA_ALT';

UPDATE PlayerColors
SET Alt3PrimaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'LEADER_VICTORIA_ALT';

UPDATE PlayerColors
SET Alt3SecondaryColor = "COLOR_STANDARD_RED_DK"
WHERE Type = 'LEADER_VICTORIA_ALT';

-- Elizabeth --

UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'LEADER_ELIZABETH';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_RED_DK"
WHERE Type = 'LEADER_ELIZABETH';

UPDATE PlayerColors
SET Alt1PrimaryColor = "COLOR_STANDARD_RED_DK"
WHERE Type = 'LEADER_ELIZABETH';

UPDATE PlayerColors
SET Alt1SecondaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'LEADER_ELIZABETH';

UPDATE PlayerColors
SET Alt2PrimaryColor = "COLOR_STANDARD_BLUE_DK"
WHERE Type = 'LEADER_ELIZABETH';

UPDATE PlayerColors
SET Alt2SecondaryColor = "COLOR_STANDARD_YELLOW_MD"
WHERE Type = 'LEADER_ELIZABETH';

UPDATE PlayerColors
SET Alt3PrimaryColor = "COLOR_STANDARD_GREEN_MD"
WHERE Type = 'LEADER_ELIZABETH';

UPDATE PlayerColors
SET Alt3SecondaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'LEADER_ELIZABETH';

--------------------------------------------------------------
-- Ethiopia --
--------------------------------------------------------------
UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_LIME_DK"
WHERE Type = 'LEADER_MENELIK';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_YELLOW_MD"
WHERE Type = 'LEADER_MENELIK';

UPDATE PlayerColors
SET Alt1PrimaryColor = "COLOR_STANDARD_YELLOW_MD"
WHERE Type = 'LEADER_MENELIK';

UPDATE PlayerColors
SET Alt1SecondaryColor = "COLOR_STANDARD_LIME_DK"
WHERE Type = 'LEADER_MENELIK';

UPDATE PlayerColors
SET Alt2PrimaryColor = "COLOR_STANDARD_YELLOW_DK"
WHERE Type = 'LEADER_MENELIK';

UPDATE PlayerColors
SET Alt2SecondaryColor = "COLOR_STANDARD_YELLOW_LT"
WHERE Type = 'LEADER_MENELIK';

UPDATE PlayerColors
SET Alt3PrimaryColor = "COLOR_STANDARD_YELLOW_LT"
WHERE Type = 'LEADER_MENELIK';

UPDATE PlayerColors
SET Alt3SecondaryColor = "COLOR_STANDARD_SAND_DK"
WHERE Type = 'LEADER_MENELIK';

--------------------------------------------------------------
-- France --
--------------------------------------------------------------

-- Catherine - Black Queen --

UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_BLUE_MD"
WHERE Type = 'LEADER_CATHERINE_DE_MEDICI';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_YELLOW_LT"
WHERE Type = 'LEADER_CATHERINE_DE_MEDICI';

UPDATE PlayerColors
SET Alt1PrimaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'LEADER_CATHERINE_DE_MEDICI';

UPDATE PlayerColors
SET Alt1SecondaryColor = "COLOR_STANDARD_YELLOW_DK"
WHERE Type = 'LEADER_CATHERINE_DE_MEDICI';

UPDATE PlayerColors
SET Alt2PrimaryColor = "COLOR_STANDARD_BLUE_DK"
WHERE Type = 'LEADER_CATHERINE_DE_MEDICI';

UPDATE PlayerColors
SET Alt2SecondaryColor = "COLOR_STANDARD_YELLOW_LT"
WHERE Type = 'LEADER_CATHERINE_DE_MEDICI';

UPDATE PlayerColors
SET Alt3PrimaryColor = "COLOR_STANDARD_YELLOW_LT"
WHERE Type = 'LEADER_CATHERINE_DE_MEDICI';

UPDATE PlayerColors
SET Alt3SecondaryColor = "COLOR_STANDARD_BLUE_DK"
WHERE Type = 'LEADER_CATHERINE_DE_MEDICI';


-- Catherine - Magnificence --

UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'LEADER_CATHERINE_DE_MEDICI_ALT';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_YELLOW_DK"
WHERE Type = 'LEADER_CATHERINE_DE_MEDICI_ALT';

UPDATE PlayerColors
SET Alt1PrimaryColor = "COLOR_STANDARD_BLUE_MD"
WHERE Type = 'LEADER_CATHERINE_DE_MEDICI_ALT';

UPDATE PlayerColors
SET Alt1SecondaryColor = "COLOR_STANDARD_YELLOW_LT"
WHERE Type = 'LEADER_CATHERINE_DE_MEDICI_ALT';

UPDATE PlayerColors
SET Alt2PrimaryColor = "COLOR_STANDARD_IMPERIAL_DK"
WHERE Type = 'LEADER_CATHERINE_DE_MEDICI_ALT';

UPDATE PlayerColors
SET Alt2SecondaryColor = "COLOR_STANDARD_YELLOW_LT"
WHERE Type = 'LEADER_CATHERINE_DE_MEDICI_ALT';

UPDATE PlayerColors
SET Alt3PrimaryColor = "COLOR_STANDARD_YELLOW_LT"
WHERE Type = 'LEADER_CATHERINE_DE_MEDICI_ALT';

UPDATE PlayerColors
SET Alt3SecondaryColor = "COLOR_STANDARD_IMPERIAL_DK"
WHERE Type = 'LEADER_CATHERINE_DE_MEDICI_ALT';

--------------------------------------------------------------
-- Gaul --
--------------------------------------------------------------
UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_GREEN_DK"
WHERE Type = 'LEADER_AMBIORIX';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_INDIGO_LT"
WHERE Type = 'LEADER_AMBIORIX';

UPDATE PlayerColors
SET Alt1PrimaryColor = "COLOR_STANDARD_YELLOW_LT"
WHERE Type = 'LEADER_AMBIORIX';

UPDATE PlayerColors
SET Alt1SecondaryColor = "COLOR_STANDARD_INDIGO_DK"
WHERE Type = 'LEADER_AMBIORIX';

UPDATE PlayerColors
SET Alt2PrimaryColor = "COLOR_STANDARD_AQUA_DK"
WHERE Type = 'LEADER_AMBIORIX';

UPDATE PlayerColors
SET Alt2SecondaryColor = "COLOR_STANDARD_YELLOW_MD"
WHERE Type = 'LEADER_AMBIORIX';

UPDATE PlayerColors
SET Alt3PrimaryColor = "COLOR_STANDARD_INDIGO_LT"
WHERE Type = 'LEADER_AMBIORIX';

UPDATE PlayerColors
SET Alt3SecondaryColor = "COLOR_STANDARD_GREEN_DK"
WHERE Type = 'LEADER_AMBIORIX';

--------------------------------------------------------------
-- Georgia --
--------------------------------------------------------------
UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'LEADER_TAMAR';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_ORANGE_DK"
WHERE Type = 'LEADER_TAMAR';

UPDATE PlayerColors
SET Alt1PrimaryColor = "COLOR_STANDARD_IMPERIAL_MD"
WHERE Type = 'LEADER_TAMAR';

UPDATE PlayerColors
SET Alt1SecondaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'LEADER_TAMAR';

UPDATE PlayerColors
SET Alt2PrimaryColor = "COLOR_STANDARD_BLUE_LT"
WHERE Type = 'LEADER_TAMAR';

UPDATE PlayerColors
SET Alt2SecondaryColor = "COLOR_STANDARD_IMPERIAL_DK"
WHERE Type = 'LEADER_TAMAR';

UPDATE PlayerColors
SET Alt3PrimaryColor = "COLOR_STANDARD_IMPERIAL_DK"
WHERE Type = 'LEADER_TAMAR';

UPDATE PlayerColors
SET Alt3SecondaryColor = "COLOR_STANDARD_BLUE_LT"
WHERE Type = 'LEADER_TAMAR';

--------------------------------------------------------------
-- Germany --
--------------------------------------------------------------

-- Barbarossa --

UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_WHITE_MD2"
WHERE Type = 'LEADER_BARBAROSSA';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_WHITE_DK"
WHERE Type = 'LEADER_BARBAROSSA';

UPDATE PlayerColors
SET Alt1PrimaryColor = "COLOR_STANDARD_YELLOW_MD"
WHERE Type = 'LEADER_BARBAROSSA';

UPDATE PlayerColors
SET Alt1SecondaryColor = "COLOR_STANDARD_WHITE_DK"
WHERE Type = 'LEADER_BARBAROSSA';

UPDATE PlayerColors
SET Alt2PrimaryColor = "COLOR_STANDARD_BLUE_DK"
WHERE Type = 'LEADER_BARBAROSSA';

UPDATE PlayerColors
SET Alt2SecondaryColor = "COLOR_STANDARD_WHITE_MD2"
WHERE Type = 'LEADER_BARBAROSSA';

UPDATE PlayerColors
SET Alt3PrimaryColor = "COLOR_STANDARD_RED_MD"
WHERE Type = 'LEADER_BARBAROSSA';

UPDATE PlayerColors
SET Alt3SecondaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'LEADER_BARBAROSSA';

-- Ludwig --

UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_INDIGO_MD"
WHERE Type = 'LEADER_LUDWIG';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'LEADER_LUDWIG';

UPDATE PlayerColors
SET Alt1PrimaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'LEADER_LUDWIG';

UPDATE PlayerColors
SET Alt1SecondaryColor = "COLOR_STANDARD_INDIGO_MD"
WHERE Type = 'LEADER_LUDWIG';

UPDATE PlayerColors
SET Alt2PrimaryColor = "COLOR_STANDARD_YELLOW_MD"
WHERE Type = 'LEADER_LUDWIG';

UPDATE PlayerColors
SET Alt2SecondaryColor = "COLOR_STANDARD_WHITE_DK"
WHERE Type = 'LEADER_LUDWIG';

UPDATE PlayerColors
SET Alt3PrimaryColor = "COLOR_STANDARD_BLUE_DK"
WHERE Type = 'LEADER_LUDWIG';

UPDATE PlayerColors
SET Alt3SecondaryColor = "COLOR_STANDARD_WHITE_MD2"
WHERE Type = 'LEADER_LUDWIG';

--------------------------------------------------------------
-- Greece --
--------------------------------------------------------------

-- Gorgo --

UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_RED_DK"
WHERE Type = 'LEADER_GORGO';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_INDIGO_LT"
WHERE Type = 'LEADER_GORGO';

UPDATE PlayerColors
SET Alt1PrimaryColor = "COLOR_STANDARD_INDIGO_LT"
WHERE Type = 'LEADER_GORGO';

UPDATE PlayerColors
SET Alt1SecondaryColor = "COLOR_STANDARD_RED_DK"
WHERE Type = 'LEADER_GORGO';

UPDATE PlayerColors
SET Alt2PrimaryColor = "COLOR_STANDARD_INDIGO_DK"
WHERE Type = 'LEADER_GORGO';

UPDATE PlayerColors
SET Alt2SecondaryColor = "COLOR_STANDARD_INDIGO_LT"
WHERE Type = 'LEADER_GORGO';

UPDATE PlayerColors
SET Alt3PrimaryColor = "COLOR_STANDARD_ORANGE_LT"
WHERE Type = 'LEADER_GORGO';

UPDATE PlayerColors
SET Alt3SecondaryColor = "COLOR_STANDARD_SAND_DK"
WHERE Type = 'LEADER_GORGO';

-- Pericles --

UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_INDIGO_MD"
WHERE Type = 'LEADER_PERICLES';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'LEADER_PERICLES';

UPDATE PlayerColors
SET Alt1PrimaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'LEADER_PERICLES';

UPDATE PlayerColors
SET Alt1SecondaryColor = "COLOR_STANDARD_INDIGO_MD"
WHERE Type = 'LEADER_PERICLES';

UPDATE PlayerColors
SET Alt2PrimaryColor = "COLOR_STANDARD_INDIGO_DK"
WHERE Type = 'LEADER_PERICLES';

UPDATE PlayerColors
SET Alt2SecondaryColor = "COLOR_STANDARD_INDIGO_LT"
WHERE Type = 'LEADER_PERICLES';

UPDATE PlayerColors
SET Alt3PrimaryColor = "COLOR_STANDARD_ORANGE_LT"
WHERE Type = 'LEADER_PERICLES';

UPDATE PlayerColors
SET Alt3SecondaryColor = "COLOR_STANDARD_SAND_DK"
WHERE Type = 'LEADER_PERICLES';

--------------------------------------------------------------
-- Hungary --
--------------------------------------------------------------
UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_GREEN_DK"
WHERE Type = 'LEADER_MATTHIAS_CORVINUS';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_RED_MD"
WHERE Type = 'LEADER_MATTHIAS_CORVINUS';

UPDATE PlayerColors
SET Alt1PrimaryColor = "COLOR_STANDARD_RED_MD"
WHERE Type = 'LEADER_MATTHIAS_CORVINUS';

UPDATE PlayerColors
SET Alt1SecondaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'LEADER_MATTHIAS_CORVINUS';

UPDATE PlayerColors
SET Alt2PrimaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'LEADER_MATTHIAS_CORVINUS';

UPDATE PlayerColors
SET Alt2SecondaryColor = "COLOR_STANDARD_LIME_DK"
WHERE Type = 'LEADER_MATTHIAS_CORVINUS';

UPDATE PlayerColors
SET Alt3PrimaryColor = "COLOR_STANDARD_LIME_DK"
WHERE Type = 'LEADER_MATTHIAS_CORVINUS';

UPDATE PlayerColors
SET Alt3SecondaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'LEADER_MATTHIAS_CORVINUS';

--------------------------------------------------------------
-- Inca --
--------------------------------------------------------------
UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_ORANGE_DK"
WHERE Type = 'LEADER_PACHACUTI';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_YELLOW_MD"
WHERE Type = 'LEADER_PACHACUTI';

UPDATE PlayerColors
SET Alt1PrimaryColor = "COLOR_STANDARD_ORANGE_LT"
WHERE Type = 'LEADER_PACHACUTI';

UPDATE PlayerColors
SET Alt1SecondaryColor = "COLOR_STANDARD_AQUA_DK"
WHERE Type = 'LEADER_PACHACUTI';

UPDATE PlayerColors
SET Alt2PrimaryColor = "COLOR_STANDARD_AQUA_DK"
WHERE Type = 'LEADER_PACHACUTI';

UPDATE PlayerColors
SET Alt2SecondaryColor = "COLOR_STANDARD_ORANGE_LT"
WHERE Type = 'LEADER_PACHACUTI';

UPDATE PlayerColors
SET Alt3PrimaryColor = "COLOR_STANDARD_YELLOW_MD"
WHERE Type = 'LEADER_PACHACUTI';

UPDATE PlayerColors
SET Alt3SecondaryColor = "COLOR_STANDARD_ORANGE_DK"
WHERE Type = 'LEADER_PACHACUTI';

--------------------------------------------------------------
-- India --
--------------------------------------------------------------

-- Gandhi --

UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_MAGENTA_DK"
WHERE Type = 'LEADER_GANDHI';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_AQUA_MD"
WHERE Type = 'LEADER_GANDHI';

UPDATE PlayerColors
SET Alt1PrimaryColor = "COLOR_STANDARD_AQUA_MD"
WHERE Type = 'LEADER_GANDHI';

UPDATE PlayerColors
SET Alt1SecondaryColor = "COLOR_STANDARD_MAGENTA_DK"
WHERE Type = 'LEADER_GANDHI';

UPDATE PlayerColors
SET Alt2PrimaryColor = "COLOR_STANDARD_GREEN_DK"
WHERE Type = 'LEADER_GANDHI';

UPDATE PlayerColors
SET Alt2SecondaryColor = "COLOR_STANDARD_ORANGE_LT"
WHERE Type = 'LEADER_GANDHI';

UPDATE PlayerColors
SET Alt3PrimaryColor = "COLOR_STANDARD_ORANGE_LT"
WHERE Type = 'LEADER_GANDHI';

UPDATE PlayerColors
SET Alt3SecondaryColor = "COLOR_STANDARD_GREEN_DK"
WHERE Type = 'LEADER_GANDHI';

-- Chandragupta --

UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_AQUA_MD"
WHERE Type = 'LEADER_CHANDRAGUPTA';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_MAGENTA_DK"
WHERE Type = 'LEADER_CHANDRAGUPTA';

UPDATE PlayerColors
SET Alt1PrimaryColor = "COLOR_STANDARD_MAGENTA_DK"
WHERE Type = 'LEADER_CHANDRAGUPTA';

UPDATE PlayerColors
SET Alt1SecondaryColor = "COLOR_STANDARD_AQUA_MD"
WHERE Type = 'LEADER_CHANDRAGUPTA';

UPDATE PlayerColors
SET Alt2PrimaryColor = "COLOR_STANDARD_ORANGE_LT"
WHERE Type = 'LEADER_CHANDRAGUPTA';

UPDATE PlayerColors
SET Alt2SecondaryColor = "COLOR_STANDARD_PURPLE_DK"
WHERE Type = 'LEADER_CHANDRAGUPTA';

UPDATE PlayerColors
SET Alt3PrimaryColor = "COLOR_STANDARD_PURPLE_DK"
WHERE Type = 'LEADER_CHANDRAGUPTA';

UPDATE PlayerColors
SET Alt3SecondaryColor = "COLOR_STANDARD_ORANGE_LT"
WHERE Type = 'LEADER_CHANDRAGUPTA';

--------------------------------------------------------------
-- Indonesia --
--------------------------------------------------------------
UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_RED_DK"
WHERE Type = 'LEADER_GITARJA';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_AQUA_MD"
WHERE Type = 'LEADER_GITARJA';

UPDATE PlayerColors
SET Alt1PrimaryColor = "COLOR_STANDARD_AQUA_MD"
WHERE Type = 'LEADER_GITARJA';

UPDATE PlayerColors
SET Alt1SecondaryColor = "COLOR_STANDARD_RED_DK"
WHERE Type = 'LEADER_GITARJA';

UPDATE PlayerColors
SET Alt2PrimaryColor = "COLOR_STANDARD_RED_MD"
WHERE Type = 'LEADER_GITARJA';

UPDATE PlayerColors
SET Alt2SecondaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'LEADER_GITARJA';

UPDATE PlayerColors
SET Alt3PrimaryColor = "COLOR_STANDARD_BLUE_DK"
WHERE Type = 'LEADER_GITARJA';

UPDATE PlayerColors
SET Alt3SecondaryColor = "COLOR_STANDARD_AQUA_LT"
WHERE Type = 'LEADER_GITARJA';

--------------------------------------------------------------
-- Japan --
--------------------------------------------------------------

-- Hojo --

UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'LEADER_HOJO';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_IMPERIAL_DK"
WHERE Type = 'LEADER_HOJO';

UPDATE PlayerColors
SET Alt1PrimaryColor = "COLOR_STANDARD_IMPERIAL_DK"
WHERE Type = 'LEADER_HOJO';

UPDATE PlayerColors
SET Alt1SecondaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'LEADER_HOJO';

UPDATE PlayerColors
SET Alt2PrimaryColor = "COLOR_STANDARD_IMPERIAL_MD"
WHERE Type = 'LEADER_HOJO';

UPDATE PlayerColors
SET Alt2SecondaryColor = "COLOR_STANDARD_YELLOW_LT"
WHERE Type = 'LEADER_HOJO';

UPDATE PlayerColors
SET Alt3PrimaryColor = "COLOR_STANDARD_BLUE_MD"
WHERE Type = 'LEADER_HOJO';

UPDATE PlayerColors
SET Alt3SecondaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'LEADER_HOJO';

-- Tokugawa --

UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_IMPERIAL_DK"
WHERE Type = 'LEADER_TOKUGAWA';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'LEADER_TOKUGAWA';

UPDATE PlayerColors
SET Alt1PrimaryColor = "COLOR_STANDARD_IMPERIAL_MD"
WHERE Type = 'LEADER_TOKUGAWA';

UPDATE PlayerColors
SET Alt1SecondaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'LEADER_TOKUGAWA';

UPDATE PlayerColors
SET Alt2PrimaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'LEADER_TOKUGAWA';

UPDATE PlayerColors
SET Alt2SecondaryColor = "COLOR_STANDARD_YELLOW_DK"
WHERE Type = 'LEADER_TOKUGAWA';

UPDATE PlayerColors
SET Alt3PrimaryColor = "COLOR_STANDARD_YELLOW_MD"
WHERE Type = 'LEADER_TOKUGAWA';

UPDATE PlayerColors
SET Alt3SecondaryColor = "COLOR_STANDARD_WHITE_DK"
WHERE Type = 'LEADER_TOKUGAWA';


--------------------------------------------------------------
-- Khmer --
--------------------------------------------------------------
UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_YELLOW_MD"
WHERE Type = 'LEADER_JAYAVARMAN';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_BLUE_DK"
WHERE Type = 'LEADER_JAYAVARMAN';

UPDATE PlayerColors
SET Alt1PrimaryColor = "COLOR_STANDARD_BLUE_DK"
WHERE Type = 'LEADER_JAYAVARMAN';

UPDATE PlayerColors
SET Alt1SecondaryColor = "COLOR_STANDARD_YELLOW_MD"
WHERE Type = 'LEADER_JAYAVARMAN';

UPDATE PlayerColors
SET Alt2PrimaryColor = "COLOR_STANDARD_ORANGE_LT"
WHERE Type = 'LEADER_JAYAVARMAN';

UPDATE PlayerColors
SET Alt2SecondaryColor = "COLOR_STANDARD_MAGENTA_DK"
WHERE Type = 'LEADER_JAYAVARMAN';

UPDATE PlayerColors
SET Alt3PrimaryColor = "COLOR_STANDARD_MAGENTA_DK"
WHERE Type = 'LEADER_JAYAVARMAN';

UPDATE PlayerColors
SET Alt3SecondaryColor = "COLOR_STANDARD_ORANGE_LT"
WHERE Type = 'LEADER_JAYAVARMAN';

--------------------------------------------------------------
-- Kongo --
--------------------------------------------------------------

-- Mvemba --

UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_YELLOW_MD"
WHERE Type = 'LEADER_MVEMBA';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_RED_MD"
WHERE Type = 'LEADER_MVEMBA';

UPDATE PlayerColors
SET Alt1PrimaryColor = "COLOR_STANDARD_RED_MD"
WHERE Type = 'LEADER_MVEMBA';

UPDATE PlayerColors
SET Alt1SecondaryColor = "COLOR_STANDARD_YELLOW_MD"
WHERE Type = 'LEADER_MVEMBA';

UPDATE PlayerColors
SET Alt2PrimaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'LEADER_MVEMBA';

UPDATE PlayerColors
SET Alt2SecondaryColor = "COLOR_STANDARD_RED_DK"
WHERE Type = 'LEADER_MVEMBA';

UPDATE PlayerColors
SET Alt3PrimaryColor = "COLOR_STANDARD_RED_DK"
WHERE Type = 'LEADER_MVEMBA';

UPDATE PlayerColors
SET Alt3SecondaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'LEADER_MVEMBA';

-- Nzinga Mbande --

UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_RED_MD"
WHERE Type = 'LEADER_NZINGA_MBANDE';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_LIME_LT"
WHERE Type = 'LEADER_NZINGA_MBANDE';

UPDATE PlayerColors
SET Alt1PrimaryColor = "COLOR_STANDARD_LIME_LT"
WHERE Type = 'LEADER_NZINGA_MBANDE';

UPDATE PlayerColors
SET Alt1SecondaryColor = "COLOR_STANDARD_RED_MD"
WHERE Type = 'LEADER_NZINGA_MBANDE';

UPDATE PlayerColors
SET Alt2PrimaryColor = "COLOR_STANDARD_RED_DK"
WHERE Type = 'LEADER_NZINGA_MBANDE';

UPDATE PlayerColors
SET Alt2SecondaryColor = "COLOR_STANDARD_AQUA_LT"
WHERE Type = 'LEADER_NZINGA_MBANDE';

UPDATE PlayerColors
SET Alt3PrimaryColor = "COLOR_STANDARD_AQUA_LT"
WHERE Type = 'LEADER_NZINGA_MBANDE';

UPDATE PlayerColors
SET Alt3SecondaryColor = "COLOR_STANDARD_RED_DK"
WHERE Type = 'LEADER_NZINGA_MBANDE';

--------------------------------------------------------------
-- Korea --
--------------------------------------------------------------

-- Seondeok --

UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_IMPERIAL_MD"
WHERE Type = 'LEADER_SEONDEOK';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_BLUE_LT"
WHERE Type = 'LEADER_SEONDEOK';

UPDATE PlayerColors
SET Alt1PrimaryColor = "COLOR_STANDARD_BLUE_LT"
WHERE Type = 'LEADER_SEONDEOK';

UPDATE PlayerColors
SET Alt1SecondaryColor = "COLOR_STANDARD_IMPERIAL_DK"
WHERE Type = 'LEADER_SEONDEOK';

UPDATE PlayerColors
SET Alt2PrimaryColor = "COLOR_STANDARD_BLUE_DK"
WHERE Type = 'LEADER_SEONDEOK';

UPDATE PlayerColors
SET Alt2SecondaryColor = "COLOR_STANDARD_RED_MD"
WHERE Type = 'LEADER_SEONDEOK';

UPDATE PlayerColors
SET Alt3PrimaryColor = "COLOR_STANDARD_RED_MD"
WHERE Type = 'LEADER_SEONDEOK';

UPDATE PlayerColors
SET Alt3SecondaryColor = "COLOR_STANDARD_ORANGE_LT"
WHERE Type = 'LEADER_SEONDEOK';

-- Sejong --

UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_RED_MD"
WHERE Type = 'LEADER_SEJONG';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_ORANGE_LT"
WHERE Type = 'LEADER_SEJONG';

UPDATE PlayerColors
SET Alt1PrimaryColor = "COLOR_STANDARD_ORANGE_LT"
WHERE Type = 'LEADER_SEJONG';

UPDATE PlayerColors
SET Alt1SecondaryColor = "COLOR_STANDARD_RED_DK"
WHERE Type = 'LEADER_SEJONG';

UPDATE PlayerColors
SET Alt2PrimaryColor = "COLOR_STANDARD_BLUE_DK"
WHERE Type = 'LEADER_SEJONG';

UPDATE PlayerColors
SET Alt2SecondaryColor = "COLOR_STANDARD_RED_MD"
WHERE Type = 'LEADER_SEJONG';

UPDATE PlayerColors
SET Alt3PrimaryColor = "COLOR_STANDARD_IMPERIAL_MD"
WHERE Type = 'LEADER_SEJONG';

UPDATE PlayerColors
SET Alt3SecondaryColor = "COLOR_STANDARD_BLUE_LT"
WHERE Type = 'LEADER_SEJONG';

--------------------------------------------------------------
-- Macedon --
--------------------------------------------------------------
UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_WHITE_MD3"
WHERE Type = 'LEADER_ALEXANDER';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_YELLOW_MD"
WHERE Type = 'LEADER_ALEXANDER';

UPDATE PlayerColors
SET Alt1PrimaryColor = "COLOR_STANDARD_PURPLE_MD"
WHERE Type = 'LEADER_ALEXANDER';

UPDATE PlayerColors
SET Alt1SecondaryColor = "COLOR_STANDARD_YELLOW_MD"
WHERE Type = 'LEADER_ALEXANDER';

UPDATE PlayerColors
SET Alt2PrimaryColor = "COLOR_STANDARD_RED_MD"
WHERE Type = 'LEADER_ALEXANDER';

UPDATE PlayerColors
SET Alt2SecondaryColor = "COLOR_STANDARD_YELLOW_LT"
WHERE Type = 'LEADER_ALEXANDER';

UPDATE PlayerColors
SET Alt3PrimaryColor = "COLOR_STANDARD_INDIGO_MD"
WHERE Type = 'LEADER_ALEXANDER';

UPDATE PlayerColors
SET Alt3SecondaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'LEADER_ALEXANDER';

--------------------------------------------------------------
-- Mali --
--------------------------------------------------------------

-- Musa --

UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_RED_DK"
WHERE Type = 'LEADER_MANSA_MUSA';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_YELLOW_LT"
WHERE Type = 'LEADER_MANSA_MUSA';

UPDATE PlayerColors
SET Alt1PrimaryColor = "COLOR_STANDARD_YELLOW_LT"
WHERE Type = 'LEADER_MANSA_MUSA';

UPDATE PlayerColors
SET Alt1SecondaryColor = "COLOR_STANDARD_RED_DK"
WHERE Type = 'LEADER_MANSA_MUSA';

UPDATE PlayerColors
SET Alt2PrimaryColor = "COLOR_STANDARD_SAND_DK"
WHERE Type = 'LEADER_MANSA_MUSA';

UPDATE PlayerColors
SET Alt2SecondaryColor = "COLOR_STANDARD_YELLOW_MD"
WHERE Type = 'LEADER_MANSA_MUSA';

UPDATE PlayerColors
SET Alt3PrimaryColor = "COLOR_STANDARD_YELLOW_MD"
WHERE Type = 'LEADER_MANSA_MUSA';

UPDATE PlayerColors
SET Alt3SecondaryColor = "COLOR_STANDARD_SAND_DK"
WHERE Type = 'LEADER_MANSA_MUSA';

-- Sundiata --

UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_YELLOW_MD"
WHERE Type = 'LEADER_SUNDIATA_KEITA';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_SAND_DK"
WHERE Type = 'LEADER_SUNDIATA_KEITA';

UPDATE PlayerColors
SET Alt1PrimaryColor = "COLOR_STANDARD_SAND_DK"
WHERE Type = 'LEADER_SUNDIATA_KEITA';

UPDATE PlayerColors
SET Alt1SecondaryColor = "COLOR_STANDARD_YELLOW_MD"
WHERE Type = 'LEADER_SUNDIATA_KEITA';

UPDATE PlayerColors
SET Alt2PrimaryColor = "COLOR_STANDARD_YELLOW_LT"
WHERE Type = 'LEADER_SUNDIATA_KEITA';

UPDATE PlayerColors
SET Alt2SecondaryColor = "COLOR_STANDARD_RED_DK"
WHERE Type = 'LEADER_SUNDIATA_KEITA';

UPDATE PlayerColors
SET Alt3PrimaryColor = "COLOR_STANDARD_RED_DK"
WHERE Type = 'LEADER_SUNDIATA_KEITA';

UPDATE PlayerColors
SET Alt3SecondaryColor = "COLOR_STANDARD_YELLOW_LT"
WHERE Type = 'LEADER_SUNDIATA_KEITA';

--------------------------------------------------------------
-- Maori --
--------------------------------------------------------------
UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_RED_MD"
WHERE Type = 'LEADER_KUPE';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_AQUA_LT"
WHERE Type = 'LEADER_KUPE';

UPDATE PlayerColors
SET Alt1PrimaryColor = "COLOR_STANDARD_AQUA_LT"
WHERE Type = 'LEADER_KUPE';

UPDATE PlayerColors
SET Alt1SecondaryColor = "COLOR_STANDARD_RED_MD"
WHERE Type = 'LEADER_KUPE';

UPDATE PlayerColors
SET Alt2PrimaryColor = "COLOR_STANDARD_SAND_DK"
WHERE Type = 'LEADER_KUPE';

UPDATE PlayerColors
SET Alt2SecondaryColor = "COLOR_STANDARD_SAND_LT"
WHERE Type = 'LEADER_KUPE';

UPDATE PlayerColors
SET Alt3PrimaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'LEADER_KUPE';

UPDATE PlayerColors
SET Alt3SecondaryColor = "COLOR_STANDARD_SAND_DK"
WHERE Type = 'LEADER_KUPE';

--------------------------------------------------------------
-- Mapuche --
--------------------------------------------------------------
UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_BLUE_MD"
WHERE Type = 'LEADER_LAUTARO';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_INDIGO_LT"
WHERE Type = 'LEADER_LAUTARO';

UPDATE PlayerColors
SET Alt1PrimaryColor = "COLOR_STANDARD_INDIGO_LT"
WHERE Type = 'LEADER_LAUTARO';

UPDATE PlayerColors
SET Alt1SecondaryColor = "COLOR_STANDARD_BLUE_DK"
WHERE Type = 'LEADER_LAUTARO';

UPDATE PlayerColors
SET Alt2PrimaryColor = "COLOR_STANDARD_ORANGE_DK"
WHERE Type = 'LEADER_LAUTARO';

UPDATE PlayerColors
SET Alt2SecondaryColor = "COLOR_STANDARD_YELLOW_LT"
WHERE Type = 'LEADER_LAUTARO';

UPDATE PlayerColors
SET Alt3PrimaryColor = "COLOR_STANDARD_YELLOW_LT"
WHERE Type = 'LEADER_LAUTARO';

UPDATE PlayerColors
SET Alt3SecondaryColor = "COLOR_STANDARD_ORANGE_DK"
WHERE Type = 'LEADER_LAUTARO';

--------------------------------------------------------------
-- Maya --
--------------------------------------------------------------
UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_BLUE_LT"
WHERE Type = 'LEADER_LADY_SIX_SKY';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_AQUA_DK"
WHERE Type = 'LEADER_LADY_SIX_SKY';

UPDATE PlayerColors
SET Alt1PrimaryColor = "COLOR_STANDARD_AQUA_DK"
WHERE Type = 'LEADER_LADY_SIX_SKY';

UPDATE PlayerColors
SET Alt1SecondaryColor = "COLOR_STANDARD_BLUE_LT"
WHERE Type = 'LEADER_LADY_SIX_SKY';

UPDATE PlayerColors
SET Alt2PrimaryColor = "COLOR_STANDARD_ORANGE_LT"
WHERE Type = 'LEADER_LADY_SIX_SKY';

UPDATE PlayerColors
SET Alt2SecondaryColor = "COLOR_STANDARD_INDIGO_DK"
WHERE Type = 'LEADER_LADY_SIX_SKY';

UPDATE PlayerColors
SET Alt3PrimaryColor = "COLOR_STANDARD_BLUE_DK"
WHERE Type = 'LEADER_LADY_SIX_SKY';

UPDATE PlayerColors
SET Alt3SecondaryColor = "COLOR_STANDARD_AQUA_LT"
WHERE Type = 'LEADER_LADY_SIX_SKY';

--------------------------------------------------------------
-- Mongolia --
--------------------------------------------------------------

-- Genghis --

UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_RED_DK"
WHERE Type = 'LEADER_GENGHIS_KHAN';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_ORANGE_MD"
WHERE Type = 'LEADER_GENGHIS_KHAN';

UPDATE PlayerColors
SET Alt1PrimaryColor = "COLOR_STANDARD_ORANGE_MD"
WHERE Type = 'LEADER_GENGHIS_KHAN';

UPDATE PlayerColors
SET Alt1SecondaryColor = "COLOR_STANDARD_RED_DK"
WHERE Type = 'LEADER_GENGHIS_KHAN';

UPDATE PlayerColors
SET Alt2PrimaryColor = "COLOR_STANDARD_YELLOW_LT"
WHERE Type = 'LEADER_GENGHIS_KHAN';

UPDATE PlayerColors
SET Alt2SecondaryColor = "COLOR_STANDARD_SAND_DK"
WHERE Type = 'LEADER_GENGHIS_KHAN';

UPDATE PlayerColors
SET Alt3PrimaryColor = "COLOR_STANDARD_INDIGO_DK"
WHERE Type = 'LEADER_GENGHIS_KHAN';

UPDATE PlayerColors
SET Alt3SecondaryColor = "COLOR_STANDARD_INDIGO_LT"
WHERE Type = 'LEADER_GENGHIS_KHAN';

-- Kublai --

UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_ORANGE_MD"
WHERE Type = 'LEADER_KUBLAI_KHAN_MONGOLIA';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_RED_DK"
WHERE Type = 'LEADER_KUBLAI_KHAN_MONGOLIA';

UPDATE PlayerColors
SET Alt1PrimaryColor = "COLOR_STANDARD_RED_DK"
WHERE Type = 'LEADER_KUBLAI_KHAN_MONGOLIA';

UPDATE PlayerColors
SET Alt1SecondaryColor = "COLOR_STANDARD_ORANGE_MD"
WHERE Type = 'LEADER_KUBLAI_KHAN_MONGOLIA';

UPDATE PlayerColors
SET Alt2PrimaryColor = "COLOR_STANDARD_INDIGO_LT"
WHERE Type = 'LEADER_KUBLAI_KHAN_MONGOLIA';

UPDATE PlayerColors
SET Alt2SecondaryColor = "COLOR_STANDARD_INDIGO_DK"
WHERE Type = 'LEADER_KUBLAI_KHAN_MONGOLIA';

UPDATE PlayerColors
SET Alt3PrimaryColor = "COLOR_STANDARD_INDIGO_DK"
WHERE Type = 'LEADER_KUBLAI_KHAN_MONGOLIA';

UPDATE PlayerColors
SET Alt3SecondaryColor = "COLOR_STANDARD_INDIGO_LT"
WHERE Type = 'LEADER_KUBLAI_KHAN_MONGOLIA';

--------------------------------------------------------------
-- Netherlands --
--------------------------------------------------------------
UPDATE PlayerColors
SET Alt1PrimaryColor = "COLOR_STANDARD_ORANGE_MD"
WHERE Type = 'LEADER_WILHELMINA';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_BLUE_DK"
WHERE Type = 'LEADER_WILHELMINA';

UPDATE PlayerColors
SET Alt1PrimaryColor = "COLOR_STANDARD_BLUE_MD"
WHERE Type = 'LEADER_WILHELMINA';

UPDATE PlayerColors
SET Alt1SecondaryColor = "COLOR_STANDARD_ORANGE_LT"
WHERE Type = 'LEADER_WILHELMINA';

UPDATE PlayerColors
SET Alt2PrimaryColor = "COLOR_STANDARD_ORANGE_LT"
WHERE Type = 'LEADER_WILHELMINA';

UPDATE PlayerColors
SET Alt2SecondaryColor = "COLOR_STANDARD_BLUE_MD"
WHERE Type = 'LEADER_WILHELMINA';

UPDATE PlayerColors
SET Alt3PrimaryColor = "COLOR_STANDARD_RED_MD"
WHERE Type = 'LEADER_WILHELMINA';

UPDATE PlayerColors
SET Alt3SecondaryColor = "COLOR_STANDARD_ORANGE_LT"
WHERE Type = 'LEADER_WILHELMINA';

--------------------------------------------------------------
-- Norway --
--------------------------------------------------------------

-- Harald - Konge --

UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_BLUE_DK"
WHERE Type = 'LEADER_HARDRADA';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_RED_MD"
WHERE Type = 'LEADER_HARDRADA';

UPDATE PlayerColors
SET Alt1PrimaryColor = "COLOR_STANDARD_RED_MD"
WHERE Type = 'LEADER_HARDRADA';

UPDATE PlayerColors
SET Alt1SecondaryColor = "COLOR_STANDARD_YELLOW_MD"
WHERE Type = 'LEADER_HARDRADA';

UPDATE PlayerColors
SET Alt2PrimaryColor = "COLOR_STANDARD_YELLOW_MD"
WHERE Type = 'LEADER_HARDRADA';

UPDATE PlayerColors
SET Alt2SecondaryColor = "COLOR_STANDARD_INDIGO_DK"
WHERE Type = 'LEADER_HARDRADA';

UPDATE PlayerColors
SET Alt3PrimaryColor = "COLOR_STANDARD_ORANGE_DK"
WHERE Type = 'LEADER_HARDRADA';

UPDATE PlayerColors
SET Alt3SecondaryColor = "COLOR_STANDARD_YELLOW_LT"
WHERE Type = 'LEADER_HARDRADA';

-- Harald - Varangian --

UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_YELLOW_MD"
WHERE Type = 'LEADER_HARALD_ALT';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_INDIGO_DK"
WHERE Type = 'LEADER_HARALD_ALT';

UPDATE PlayerColors
SET Alt1PrimaryColor = "COLOR_STANDARD_RED_MD"
WHERE Type = 'LEADER_HARALD_ALT';

UPDATE PlayerColors
SET Alt1SecondaryColor = "COLOR_STANDARD_YELLOW_MD"
WHERE Type = 'LEADER_HARALD_ALT';

UPDATE PlayerColors
SET Alt2PrimaryColor = "COLOR_STANDARD_BLUE_DK"
WHERE Type = 'LEADER_HARALD_ALT';

UPDATE PlayerColors
SET Alt2SecondaryColor = "COLOR_STANDARD_RED_MD"
WHERE Type = 'LEADER_HARALD_ALT';

UPDATE PlayerColors
SET Alt3PrimaryColor = "COLOR_STANDARD_PURPLE_DK"
WHERE Type = 'LEADER_HARALD_ALT';

UPDATE PlayerColors
SET Alt3SecondaryColor = "COLOR_STANDARD_BLUE_LT"
WHERE Type = 'LEADER_HARALD_ALT';

--------------------------------------------------------------
-- Nubia --
--------------------------------------------------------------
UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_SAND_LT"
WHERE Type = 'LEADER_AMANITORE';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_SAND_DK"
WHERE Type = 'LEADER_AMANITORE';

UPDATE PlayerColors
SET Alt1PrimaryColor = "COLOR_STANDARD_SAND_DK"
WHERE Type = 'LEADER_AMANITORE';

UPDATE PlayerColors
SET Alt1SecondaryColor = "COLOR_STANDARD_SAND_LT"
WHERE Type = 'LEADER_AMANITORE';

UPDATE PlayerColors
SET Alt2PrimaryColor = "COLOR_STANDARD_YELLOW_LT"
WHERE Type = 'LEADER_AMANITORE';

UPDATE PlayerColors
SET Alt2SecondaryColor = "COLOR_STANDARD_ORANGE_DK"
WHERE Type = 'LEADER_AMANITORE';

UPDATE PlayerColors
SET Alt3PrimaryColor = "COLOR_STANDARD_ORANGE_DK"
WHERE Type = 'LEADER_AMANITORE';

UPDATE PlayerColors
SET Alt3SecondaryColor = "COLOR_STANDARD_YELLOW_LT"
WHERE Type = 'LEADER_AMANITORE';

--------------------------------------------------------------
-- Ottomans --
--------------------------------------------------------------

-- Suleiman - Kanuni --

UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'LEADER_SULEIMAN';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_GREEN_DK"
WHERE Type = 'LEADER_SULEIMAN';

UPDATE PlayerColors
SET Alt1PrimaryColor = "COLOR_STANDARD_GREEN_DK"
WHERE Type = 'LEADER_SULEIMAN';

UPDATE PlayerColors
SET Alt1SecondaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'LEADER_SULEIMAN';

UPDATE PlayerColors
SET Alt2PrimaryColor = "COLOR_STANDARD_RED_DK"
WHERE Type = 'LEADER_SULEIMAN';

UPDATE PlayerColors
SET Alt2SecondaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'LEADER_SULEIMAN';

UPDATE PlayerColors
SET Alt3PrimaryColor = "COLOR_STANDARD_GREEN_MD"
WHERE Type = 'LEADER_SULEIMAN';

UPDATE PlayerColors
SET Alt3SecondaryColor = "COLOR_STANDARD_YELLOW_LT"
WHERE Type = 'LEADER_SULEIMAN';

-- Suleiman - Muhtesem --

UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_GREEN_DK"
WHERE Type = 'LEADER_SULEIMAN_ALT';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'LEADER_SULEIMAN_ALT';

UPDATE PlayerColors
SET Alt1PrimaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'LEADER_SULEIMAN_ALT';

UPDATE PlayerColors
SET Alt1SecondaryColor = "COLOR_STANDARD_GREEN_DK"
WHERE Type = 'LEADER_SULEIMAN_ALT';

UPDATE PlayerColors
SET Alt2PrimaryColor = "COLOR_STANDARD_RED_DK"
WHERE Type = 'LEADER_SULEIMAN_ALT';

UPDATE PlayerColors
SET Alt2SecondaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'LEADER_SULEIMAN_ALT';

UPDATE PlayerColors
SET Alt3PrimaryColor = "COLOR_STANDARD_INDIGO_MD"
WHERE Type = 'LEADER_SULEIMAN_ALT';

UPDATE PlayerColors
SET Alt3SecondaryColor = "COLOR_STANDARD_YELLOW_LT"
WHERE Type = 'LEADER_SULEIMAN_ALT';

--------------------------------------------------------------
-- Persia --
--------------------------------------------------------------

-- Cyrus --

UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_BLUE_LT"
WHERE Type = 'LEADER_CYRUS';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_IMPERIAL_DK"
WHERE Type = 'LEADER_CYRUS';

UPDATE PlayerColors
SET Alt1PrimaryColor = "COLOR_STANDARD_IMPERIAL_DK"
WHERE Type = 'LEADER_CYRUS';

UPDATE PlayerColors
SET Alt1SecondaryColor = "COLOR_STANDARD_YELLOW_LT"
WHERE Type = 'LEADER_CYRUS';

UPDATE PlayerColors
SET Alt2PrimaryColor = "COLOR_STANDARD_RED_MD"
WHERE Type = 'LEADER_CYRUS';

UPDATE PlayerColors
SET Alt2SecondaryColor = "COLOR_STANDARD_YELLOW_MD"
WHERE Type = 'LEADER_CYRUS';

UPDATE PlayerColors
SET Alt3PrimaryColor = "COLOR_STANDARD_INDIGO_MD"
WHERE Type = 'LEADER_CYRUS';

UPDATE PlayerColors
SET Alt3SecondaryColor = "COLOR_STANDARD_YELLOW_MD"
WHERE Type = 'LEADER_CYRUS';

-- Nader Shah --

UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_IMPERIAL_DK"
WHERE Type = 'LEADER_NADER_SHAH';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_BLUE_LT"
WHERE Type = 'LEADER_NADER_SHAH';

UPDATE PlayerColors
SET Alt1PrimaryColor = "COLOR_STANDARD_BLUE_LT"
WHERE Type = 'LEADER_NADER_SHAH';

UPDATE PlayerColors
SET Alt1SecondaryColor = "COLOR_STANDARD_IMPERIAL_DK"
WHERE Type = 'LEADER_NADER_SHAH';

UPDATE PlayerColors
SET Alt2PrimaryColor = "COLOR_STANDARD_RED_MD"
WHERE Type = 'LEADER_NADER_SHAH';

UPDATE PlayerColors
SET Alt2SecondaryColor = "COLOR_STANDARD_YELLOW_MD"
WHERE Type = 'LEADER_NADER_SHAH';

UPDATE PlayerColors
SET Alt3PrimaryColor = "COLOR_STANDARD_GREEN_DK"
WHERE Type = 'LEADER_NADER_SHAH';

UPDATE PlayerColors
SET Alt3SecondaryColor = "COLOR_STANDARD_YELLOW_LT"
WHERE Type = 'LEADER_NADER_SHAH';

--------------------------------------------------------------
-- Phoenicia --
--------------------------------------------------------------
UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_MAGENTA_DK"
WHERE Type = 'LEADER_DIDO';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_BLUE_LT"
WHERE Type = 'LEADER_DIDO';

UPDATE PlayerColors
SET Alt1PrimaryColor = "COLOR_STANDARD_IMPERIAL_DK"
WHERE Type = 'LEADER_DIDO';

UPDATE PlayerColors
SET Alt1SecondaryColor = "COLOR_STANDARD_YELLOW_MD"
WHERE Type = 'LEADER_DIDO';

UPDATE PlayerColors
SET Alt2PrimaryColor = "COLOR_STANDARD_PURPLE_MD"
WHERE Type = 'LEADER_DIDO';

UPDATE PlayerColors
SET Alt2SecondaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'LEADER_DIDO';

UPDATE PlayerColors
SET Alt3PrimaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'LEADER_DIDO';

UPDATE PlayerColors
SET Alt3SecondaryColor = "COLOR_STANDARD_PURPLE_MD"
WHERE Type = 'LEADER_DIDO';

--------------------------------------------------------------
-- Poland --
--------------------------------------------------------------
UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_IMPERIAL_MD"
WHERE Type = 'LEADER_JADWIGA';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'LEADER_JADWIGA';

UPDATE PlayerColors
SET Alt1PrimaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'LEADER_JADWIGA';

UPDATE PlayerColors
SET Alt1SecondaryColor = "COLOR_STANDARD_IMPERIAL_DK"
WHERE Type = 'LEADER_JADWIGA';

UPDATE PlayerColors
SET Alt2PrimaryColor = "COLOR_STANDARD_IMPERIAL_DK"
WHERE Type = 'LEADER_JADWIGA';

UPDATE PlayerColors
SET Alt2SecondaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'LEADER_JADWIGA';

UPDATE PlayerColors
SET Alt3PrimaryColor = "COLOR_STANDARD_INDIGO_DK"
WHERE Type = 'LEADER_JADWIGA';

UPDATE PlayerColors
SET Alt3SecondaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'LEADER_JADWIGA';

--------------------------------------------------------------
-- Portugal --
--------------------------------------------------------------
UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'LEADER_JOAO_III';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_BLUE_DK"
WHERE Type = 'LEADER_JOAO_III';

UPDATE PlayerColors
SET Alt1PrimaryColor = "COLOR_STANDARD_BLUE_DK"
WHERE Type = 'LEADER_JOAO_III';

UPDATE PlayerColors
SET Alt1SecondaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'LEADER_JOAO_III';

UPDATE PlayerColors
SET Alt2PrimaryColor = "COLOR_STANDARD_LIME_LT"
WHERE Type = 'LEADER_JOAO_III';

UPDATE PlayerColors
SET Alt2SecondaryColor = "COLOR_STANDARD_BLUE_DK"
WHERE Type = 'LEADER_JOAO_III';

UPDATE PlayerColors
SET Alt3PrimaryColor = "COLOR_STANDARD_GREEN_DK"
WHERE Type = 'LEADER_JOAO_III';

UPDATE PlayerColors
SET Alt3SecondaryColor = "COLOR_STANDARD_RED_MD"
WHERE Type = 'LEADER_JOAO_III';

--------------------------------------------------------------
-- Rome --
--------------------------------------------------------------

-- Trajan --

UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_PURPLE_DK"
WHERE Type = 'LEADER_TRAJAN';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_YELLOW_MD"
WHERE Type = 'LEADER_TRAJAN';

UPDATE PlayerColors
SET Alt1PrimaryColor = "COLOR_STANDARD_PURPLE_MD"
WHERE Type = 'LEADER_TRAJAN';

UPDATE PlayerColors
SET Alt1SecondaryColor = "COLOR_STANDARD_YELLOW_MD"
WHERE Type = 'LEADER_TRAJAN';

UPDATE PlayerColors
SET Alt2PrimaryColor = "COLOR_STANDARD_YELLOW_MD"
WHERE Type = 'LEADER_TRAJAN';

UPDATE PlayerColors
SET Alt2SecondaryColor = "COLOR_STANDARD_PURPLE_DK"
WHERE Type = 'LEADER_TRAJAN';

UPDATE PlayerColors
SET Alt3PrimaryColor = "COLOR_STANDARD_RED_DK"
WHERE Type = 'LEADER_TRAJAN';

UPDATE PlayerColors
SET Alt3SecondaryColor = "COLOR_STANDARD_YELLOW_MD"
WHERE Type = 'LEADER_TRAJAN';

-- Julius Caesar --

UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_RED_DK"
WHERE Type = 'LEADER_JULIUS_CAESAR';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_YELLOW_MD"
WHERE Type = 'LEADER_JULIUS_CAESAR';

UPDATE PlayerColors
SET Alt1PrimaryColor = "COLOR_STANDARD_RED_MD"
WHERE Type = 'LEADER_JULIUS_CAESAR';

UPDATE PlayerColors
SET Alt1SecondaryColor = "COLOR_STANDARD_YELLOW_MD"
WHERE Type = 'LEADER_JULIUS_CAESAR';

UPDATE PlayerColors
SET Alt2PrimaryColor = "COLOR_STANDARD_YELLOW_MD"
WHERE Type = 'LEADER_JULIUS_CAESAR';

UPDATE PlayerColors
SET Alt2SecondaryColor = "COLOR_STANDARD_RED_DK"
WHERE Type = 'LEADER_JULIUS_CAESAR';

UPDATE PlayerColors
SET Alt3PrimaryColor = "COLOR_STANDARD_PURPLE_DK"
WHERE Type = 'LEADER_JULIUS_CAESAR';

UPDATE PlayerColors
SET Alt3SecondaryColor = "COLOR_STANDARD_YELLOW_MD"
WHERE Type = 'LEADER_JULIUS_CAESAR';

--------------------------------------------------------------
-- Russia --
--------------------------------------------------------------
UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_YELLOW_MD"
WHERE Type = 'LEADER_PETER_GREAT';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_WHITE_DK"
WHERE Type = 'LEADER_PETER_GREAT';

UPDATE PlayerColors
SET Alt1PrimaryColor = "COLOR_STANDARD_GREEN_DK"
WHERE Type = 'LEADER_PETER_GREAT';

UPDATE PlayerColors
SET Alt1SecondaryColor = "COLOR_STANDARD_YELLOW_MD"
WHERE Type = 'LEADER_PETER_GREAT';

UPDATE PlayerColors
SET Alt2PrimaryColor = "COLOR_STANDARD_RED_DK"
WHERE Type = 'LEADER_PETER_GREAT';

UPDATE PlayerColors
SET Alt2SecondaryColor = "COLOR_STANDARD_YELLOW_MD"
WHERE Type = 'LEADER_PETER_GREAT';

UPDATE PlayerColors
SET Alt3PrimaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'LEADER_PETER_GREAT';

UPDATE PlayerColors
SET Alt3SecondaryColor = "COLOR_STANDARD_BLUE_DK"
WHERE Type = 'LEADER_PETER_GREAT';

--------------------------------------------------------------
-- Scotland --
--------------------------------------------------------------
UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'LEADER_ROBERT_THE_BRUCE';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_INDIGO_DK"
WHERE Type = 'LEADER_ROBERT_THE_BRUCE';

UPDATE PlayerColors
SET Alt1PrimaryColor = "COLOR_STANDARD_INDIGO_DK"
WHERE Type = 'LEADER_ROBERT_THE_BRUCE';

UPDATE PlayerColors
SET Alt1SecondaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'LEADER_ROBERT_THE_BRUCE';

UPDATE PlayerColors
SET Alt2PrimaryColor = "COLOR_STANDARD_INDIGO_MD"
WHERE Type = 'LEADER_ROBERT_THE_BRUCE';

UPDATE PlayerColors
SET Alt2SecondaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'LEADER_ROBERT_THE_BRUCE';

UPDATE PlayerColors
SET Alt3PrimaryColor = "COLOR_STANDARD_YELLOW_MD"
WHERE Type = 'LEADER_ROBERT_THE_BRUCE';

UPDATE PlayerColors
SET Alt3SecondaryColor = "COLOR_STANDARD_RED_DK"
WHERE Type = 'LEADER_ROBERT_THE_BRUCE';

--------------------------------------------------------------
-- Scythia --
--------------------------------------------------------------
UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_ORANGE_LT"
WHERE Type = 'LEADER_TOMYRIS';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_RED_DK"
WHERE Type = 'LEADER_TOMYRIS';

UPDATE PlayerColors
SET Alt1PrimaryColor = "COLOR_STANDARD_ORANGE_DK"
WHERE Type = 'LEADER_TOMYRIS';

UPDATE PlayerColors
SET Alt1SecondaryColor = "COLOR_STANDARD_YELLOW_LT"
WHERE Type = 'LEADER_TOMYRIS';

UPDATE PlayerColors
SET Alt2PrimaryColor = "COLOR_STANDARD_YELLOW_LT"
WHERE Type = 'LEADER_TOMYRIS';

UPDATE PlayerColors
SET Alt2SecondaryColor = "COLOR_STANDARD_RED_DK"
WHERE Type = 'LEADER_TOMYRIS';

UPDATE PlayerColors
SET Alt3PrimaryColor = "COLOR_STANDARD_LIME_DK"
WHERE Type = 'LEADER_TOMYRIS';

UPDATE PlayerColors
SET Alt3SecondaryColor = "COLOR_STANDARD_YELLOW_LT"
WHERE Type = 'LEADER_TOMYRIS';

--------------------------------------------------------------
-- Spain --
--------------------------------------------------------------
UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_RED_MD"
WHERE Type = 'LEADER_PHILIP_II';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_YELLOW_MD"
WHERE Type = 'LEADER_PHILIP_II';

UPDATE PlayerColors
SET Alt1PrimaryColor = "COLOR_STANDARD_YELLOW_MD"
WHERE Type = 'LEADER_PHILIP_II';

UPDATE PlayerColors
SET Alt1SecondaryColor = "COLOR_STANDARD_RED_MD"
WHERE Type = 'LEADER_PHILIP_II';

UPDATE PlayerColors
SET Alt2PrimaryColor = "COLOR_STANDARD_RED_DK"
WHERE Type = 'LEADER_PHILIP_II';

UPDATE PlayerColors
SET Alt2SecondaryColor = "COLOR_STANDARD_YELLOW_MD"
WHERE Type = 'LEADER_PHILIP_II';

UPDATE PlayerColors
SET Alt3PrimaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'LEADER_PHILIP_II';

UPDATE PlayerColors
SET Alt3SecondaryColor = "COLOR_STANDARD_RED_DK"
WHERE Type = 'LEADER_PHILIP_II';

--------------------------------------------------------------
-- Sumer --
--------------------------------------------------------------
UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_BLUE_DK"
WHERE Type = 'LEADER_GILGAMESH';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_ORANGE_MD"
WHERE Type = 'LEADER_GILGAMESH';

UPDATE PlayerColors
SET Alt1PrimaryColor = "COLOR_STANDARD_BLUE_MD"
WHERE Type = 'LEADER_GILGAMESH';

UPDATE PlayerColors
SET Alt1SecondaryColor = "COLOR_STANDARD_ORANGE_LT"
WHERE Type = 'LEADER_GILGAMESH';

UPDATE PlayerColors
SET Alt2PrimaryColor = "COLOR_STANDARD_PURPLE_MD"
WHERE Type = 'LEADER_GILGAMESH';

UPDATE PlayerColors
SET Alt2SecondaryColor = "COLOR_STANDARD_ORANGE_LT"
WHERE Type = 'LEADER_GILGAMESH';

UPDATE PlayerColors
SET Alt3PrimaryColor = "COLOR_STANDARD_ORANGE_LT"
WHERE Type = 'LEADER_GILGAMESH';

UPDATE PlayerColors
SET Alt3SecondaryColor = "COLOR_STANDARD_PURPLE_DK"
WHERE Type = 'LEADER_GILGAMESH';

--------------------------------------------------------------
-- Sweden --
--------------------------------------------------------------
UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_BLUE_MD"
WHERE Type = 'LEADER_KRISTINA';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_YELLOW_MD"
WHERE Type = 'LEADER_KRISTINA';

UPDATE PlayerColors
SET Alt1PrimaryColor = "COLOR_STANDARD_YELLOW_MD"
WHERE Type = 'LEADER_KRISTINA';

UPDATE PlayerColors
SET Alt1SecondaryColor = "COLOR_STANDARD_BLUE_MD"
WHERE Type = 'LEADER_KRISTINA';

UPDATE PlayerColors
SET Alt2PrimaryColor = "COLOR_STANDARD_BLUE_DK"
WHERE Type = 'LEADER_KRISTINA';

UPDATE PlayerColors
SET Alt2SecondaryColor = "COLOR_STANDARD_YELLOW_MD"
WHERE Type = 'LEADER_KRISTINA';

UPDATE PlayerColors
SET Alt3PrimaryColor = "COLOR_STANDARD_INDIGO_MD"
WHERE Type = 'LEADER_KRISTINA';

UPDATE PlayerColors
SET Alt3SecondaryColor = "COLOR_STANDARD_YELLOW_LT"
WHERE Type = 'LEADER_KRISTINA';

--------------------------------------------------------------
-- Vietnam --
--------------------------------------------------------------
UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_YELLOW_MD"
WHERE Type = 'LEADER_LADY_TRIEU';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_MAGENTA_DK"
WHERE Type = 'LEADER_LADY_TRIEU';

UPDATE PlayerColors
SET Alt1PrimaryColor = "COLOR_STANDARD_MAGENTA_DK"
WHERE Type = 'LEADER_LADY_TRIEU';

UPDATE PlayerColors
SET Alt1SecondaryColor = "COLOR_STANDARD_YELLOW_MD"
WHERE Type = 'LEADER_LADY_TRIEU';

UPDATE PlayerColors
SET Alt2PrimaryColor = "COLOR_STANDARD_RED_MD"
WHERE Type = 'LEADER_LADY_TRIEU';

UPDATE PlayerColors
SET Alt2SecondaryColor = "COLOR_STANDARD_YELLOW_MD"
WHERE Type = 'LEADER_LADY_TRIEU';

UPDATE PlayerColors
SET Alt3PrimaryColor = "COLOR_STANDARD_AQUA_DK"
WHERE Type = 'LEADER_LADY_TRIEU';

UPDATE PlayerColors
SET Alt3SecondaryColor = "COLOR_STANDARD_YELLOW_MD"
WHERE Type = 'LEADER_LADY_TRIEU';

--------------------------------------------------------------
-- Zulu --
--------------------------------------------------------------
UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_ORANGE_DK"
WHERE Type = 'LEADER_SHAKA';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'LEADER_SHAKA';

UPDATE PlayerColors
SET Alt1PrimaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'LEADER_SHAKA';

UPDATE PlayerColors
SET Alt1SecondaryColor = "COLOR_STANDARD_ORANGE_DK"
WHERE Type = 'LEADER_SHAKA';

UPDATE PlayerColors
SET Alt2PrimaryColor = "COLOR_STANDARD_GREEN_DK"
WHERE Type = 'LEADER_SHAKA';

UPDATE PlayerColors
SET Alt2SecondaryColor = "COLOR_STANDARD_YELLOW_LT"
WHERE Type = 'LEADER_SHAKA';

UPDATE PlayerColors
SET Alt3PrimaryColor = "COLOR_STANDARD_YELLOW_LT"
WHERE Type = 'LEADER_SHAKA';

UPDATE PlayerColors
SET Alt3SecondaryColor = "COLOR_STANDARD_GREEN_DK"
WHERE Type = 'LEADER_SHAKA';

--------------------------------------------------------------
-- Generic Jerseys --
--------------------------------------------------------------
--------------------------------------------------------------
--------------------------------------------------------------

UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_GREEN_MD"
WHERE Type = 'PLAYERCOLOR_GREEN';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'PLAYERCOLOR_GREEN';

UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_ORANGE_MD"
WHERE Type = 'PLAYERCOLOR_ORANGE';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'PLAYERCOLOR_ORANGE';

UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_ORANGE_LT"
WHERE Type = 'PLAYERCOLOR_PEACH';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_IMPERIAL_DK"
WHERE Type = 'PLAYERCOLOR_PEACH';

UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_IMPERIAL_LT"
WHERE Type = 'PLAYERCOLOR_PINK';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_IMPERIAL_DK"
WHERE Type = 'PLAYERCOLOR_PINK';

UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_RED_DK"
WHERE Type = 'PLAYERCOLOR_RED';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'PLAYERCOLOR_RED';

UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'PLAYERCOLOR_WHITE';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_WHITE_MD"
WHERE Type = 'PLAYERCOLOR_WHITE';

UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_YELLOW_MD"
WHERE Type = 'PLAYERCOLOR_YELLOW';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_ORANGE_DK"
WHERE Type = 'PLAYERCOLOR_YELLOW';

UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_BLUE_LT"
WHERE Type = 'PLAYERCOLOR_LIGHT_BLUE';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_BLUE_DK"
WHERE Type = 'PLAYERCOLOR_LIGHT_BLUE';

UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_YELLOW_LT"
WHERE Type = 'PLAYERCOLOR_LIGHT_YELLOW';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_YELLOW_DK"
WHERE Type = 'PLAYERCOLOR_LIGHT_YELLOW';

UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_PURPLE_DK"
WHERE Type = 'PLAYERCOLOR_PURPLE';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'PLAYERCOLOR_PURPLE';

UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_PURPLE_LT"
WHERE Type = 'PLAYERCOLOR_LIGHT_PURPLE';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_PURPLE_DK"
WHERE Type = 'PLAYERCOLOR_LIGHT_PURPLE';

UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_PURPLE_MD"
WHERE Type = 'PLAYERCOLOR_MIDDLE_PURPLE';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'PLAYERCOLOR_MIDDLE_PURPLE';

UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'PLAYERCOLOR_LIGHT_ORANGE';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_ORANGE_MD"
WHERE Type = 'PLAYERCOLOR_LIGHT_ORANGE';

UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_GREEN_LT"
WHERE Type = 'PLAYERCOLOR_MIDDLE_GREEN';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_GREEN_DK"
WHERE Type = 'PLAYERCOLOR_MIDDLE_GREEN';

UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_INDIGO_LT"
WHERE Type = 'PLAYERCOLOR_MIDDLE_BLUE';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_INDIGO_DK"
WHERE Type = 'PLAYERCOLOR_MIDDLE_BLUE';

UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_BLUE_DK"
WHERE Type = 'PLAYERCOLOR_DARK_BLUE';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_BLUE_LT"
WHERE Type = 'PLAYERCOLOR_DARK_BLUE';

UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_AQUA_MD"
WHERE Type = 'PLAYERCOLOR_MIDDLE_CYAN';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_AQUA_DK"
WHERE Type = 'PLAYERCOLOR_MIDDLE_CYAN';

UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_SAND_LT"
WHERE Type = 'PLAYERCOLOR_LIGHT_BROWN';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_SAND_DK"
WHERE Type = 'PLAYERCOLOR_LIGHT_BROWN';

UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_ORANGE_DK"
WHERE Type = 'PLAYERCOLOR_DARK_ORANGE';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_ORANGE_LT"
WHERE Type = 'PLAYERCOLOR_DARK_ORANGE';

UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_GREEN_DK"
WHERE Type = 'PLAYERCOLOR_DARK_GREEN_AND_YELLOW';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_YELLOW_MD"
WHERE Type = 'PLAYERCOLOR_DARK_GREEN_AND_YELLOW';

UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_LIME_DK"
WHERE Type = 'PLAYERCOLOR_DARK_GREEN_AND_LIGHT_GREEN';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_LIME_LT"
WHERE Type = 'PLAYERCOLOR_DARK_GREEN_AND_LIGHT_GREEN';

UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_RED_DK"
WHERE Type = 'PLAYERCOLOR_DARK_RED_AND_CREAM';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_YELLOW_LT"
WHERE Type = 'PLAYERCOLOR_DARK_RED_AND_CREAM';

UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_BLUE_DK"
WHERE Type = 'PLAYERCOLOR_BLUE_AND_AQUA';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_AQUA_LT"
WHERE Type = 'PLAYERCOLOR_BLUE_AND_AQUA';

UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_AQUA_DK"
WHERE Type = 'PLAYERCOLOR_AQUA_DARK_AND_AQUA_LIGHT';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_AQUA_LT"
WHERE Type = 'PLAYERCOLOR_AQUA_DARK_AND_AQUA_LIGHT';

UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_GREEN_DK"
WHERE Type = 'PLAYERCOLOR_DARK_DARK_GREEN';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'PLAYERCOLOR_DARK_DARK_GREEN';

UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_INDIGO_DK"
WHERE Type = 'PLAYERCOLOR_DARK_INDIGO';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'PLAYERCOLOR_DARK_INDIGO';

UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_LIME_LT"
WHERE Type = 'PLAYERCOLOR_LIGHT_GREEN';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_LIME_DK"
WHERE Type = 'PLAYERCOLOR_LIGHT_GREEN';

UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_RED_LT"
WHERE Type = 'PLAYERCOLOR_PEACH_AND_GREEN';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_BLUE_DK"
WHERE Type = 'PLAYERCOLOR_PEACH_AND_GREEN';

UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_YELLOW_LT"
WHERE Type = 'PLAYERCOLOR_CREAM_AND_BROWN';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_ORANGE_DK"
WHERE Type = 'PLAYERCOLOR_CREAM_AND_BROWN';

UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_SAND_DK"
WHERE Type = 'PLAYERCOLOR_BROWN_AND_CREAM';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_YELLOW_LT"
WHERE Type = 'PLAYERCOLOR_BROWN_AND_CREAM';

UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_MAGENTA_DK"
WHERE Type = 'PLAYERCOLOR_DARK_MAGENTA';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'PLAYERCOLOR_DARK_MAGENTA';

UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_IMPERIAL_DK"
WHERE Type = 'PLAYERCOLOR_DARK_MAGENTA_AND_YELLOW';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_YELLOW_MD"
WHERE Type = 'PLAYERCOLOR_DARK_MAGENTA_AND_YELLOW';

UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_IMPERIAL_MD"
WHERE Type = 'PLAYERCOLOR_DARK_MAGENTA_AND_BLUE';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_BLUE_LT"
WHERE Type = 'PLAYERCOLOR_DARK_MAGENTA_AND_BLUE';

UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_RED_MD"
WHERE Type = 'PLAYERCOLOR_RED_AND_GOLD';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_YELLOW_MD"
WHERE Type = 'PLAYERCOLOR_RED_AND_GOLD';

UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_LIME_MD"
WHERE Type = 'PLAYERCOLOR_GREEN_AND_BLACK';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'PLAYERCOLOR_GREEN_AND_BLACK';

UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_INDIGO_MD"
WHERE Type = 'PLAYERCOLOR_DARK_CYAN_AND_LEMON';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_YELLOW_LT"
WHERE Type = 'PLAYERCOLOR_DARK_CYAN_AND_LEMON';

UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_GREEN_LT"
WHERE Type = 'PLAYERCOLOR_BLACK_AND_GREEN';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_BLUE_DK"
WHERE Type = 'PLAYERCOLOR_BLACK_AND_GREEN';

UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'PLAYERCOLOR_GREEN_AND_WHITE';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_GREEN_DK"
WHERE Type = 'PLAYERCOLOR_GREEN_AND_WHITE';

UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_AQUA_LT"
WHERE Type = 'PLAYERCOLOR_CYAN_AND_GRAY';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_BLUE_DK"
WHERE Type = 'PLAYERCOLOR_CYAN_AND_GRAY';

UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_INDIGO_MD"
WHERE Type = 'PLAYERCOLOR_DARK_INDIGO_AND_WHITE';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_WHITE_LT"
WHERE Type = 'PLAYERCOLOR_DARK_INDIGO_AND_WHITE';

UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_ORANGE_MD"
WHERE Type = 'PLAYERCOLOR_ORANGE_AND_GREEN';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_BLUE_DK"
WHERE Type = 'PLAYERCOLOR_ORANGE_AND_GREEN';

UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_WHITE_MD"
WHERE Type = 'PLAYERCOLOR_DARK_GRAY';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_WHITE_MD2"
WHERE Type = 'PLAYERCOLOR_DARK_GRAY';

UPDATE PlayerColors
SET PrimaryColor = "COLOR_STANDARD_WHITE_MD2"
WHERE Type = 'PLAYERCOLOR_GRAY';

UPDATE PlayerColors
SET SecondaryColor = "COLOR_STANDARD_WHITE_MD"
WHERE Type = 'PLAYERCOLOR_GRAY';

--------------------------------------------------------------
--------------------------------------------------------------
--------------------------------------------------------------
------------------------- Have fun! --------------------------
--------------------------------------------------------------
--------------------------------------------------------------
--------------------------------------------------------------
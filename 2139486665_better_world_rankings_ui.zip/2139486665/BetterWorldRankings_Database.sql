-- ===========================================================================
-- Better World Rankings
-- Author: Infixo
-- 2020-06-22: Created
-- ===========================================================================

-- just to make versioning easier
INSERT INTO GlobalParameters (Name, Value) VALUES ('BWR_VERSION_MAJOR', '1');
INSERT INTO GlobalParameters (Name, Value) VALUES ('BWR_VERSION_MINOR', '3');

-- options
--INSERT INTO GlobalParameters (Name, Value) VALUES ('BWR_OPTION', '0');

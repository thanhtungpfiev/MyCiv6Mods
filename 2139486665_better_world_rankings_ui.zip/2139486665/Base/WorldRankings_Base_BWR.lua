print("Loading WorldRankings_Base_BWR.lua from Better World Rankings version "..GlobalParameters.BWR_VERSION_MAJOR.."."..GlobalParameters.BWR_VERSION_MINOR);
-- ===========================================================================
-- Better World Rankings
-- Author: Infixo
-- 2020-06-22: Created
-- ===========================================================================

include("WorldRankings"); -- base game functionality
include("WorldRankings_BWR"); -- mod functionality

print("OK loaded WorldRankings_Base_BWR.lua from Better World Rankings");
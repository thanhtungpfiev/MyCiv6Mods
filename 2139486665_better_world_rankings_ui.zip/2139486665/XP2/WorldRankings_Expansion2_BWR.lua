print("Loading WorldRankings_Expansion2_BWR.lua from Better World Rankings version "..GlobalParameters.BWR_VERSION_MAJOR.."."..GlobalParameters.BWR_VERSION_MINOR);
-- ===========================================================================
-- Better World Rankings
-- Author: Infixo
-- 2020-06-22: Created
-- ===========================================================================

include("WorldRankings_Expansion2"); -- base game + expansion2 functionality
include("WorldRankings_BWR"); -- mod functionality

print("OK loaded WorldRankings_Expansion2_BWR.lua from Better World Rankings");
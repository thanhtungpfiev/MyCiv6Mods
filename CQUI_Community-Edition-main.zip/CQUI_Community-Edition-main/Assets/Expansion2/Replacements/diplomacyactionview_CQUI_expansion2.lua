-- ===========================================================================
-- Base File
-- ===========================================================================
include("DiplomacyActionView_Expansion2.lua");

include("diplomacyactionview_CQUI.lua");
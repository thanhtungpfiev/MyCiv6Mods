-- ===========================================================================
-- Base File
-- ===========================================================================
include("PartialScreenHooks_Expansion1");

include("partialscreenhooks_CQUI.lua");
-- This is the main CQUI script. There's not much here yet!
-- TODO: Is this file required?  The inclusion of such file isn't seen in many other mods.
--include("CQUICommon.lua");

function Initialize()
    print("CQUI Loaded! Update for v1.0.11.16 (2021-03-25)");
end
Initialize();
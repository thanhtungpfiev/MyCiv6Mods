/*
	YnAMP
	by Gedemon (2016-2020)
	
*/

INSERT OR REPLACE INTO GlobalParameters (Name, Value) VALUES ('YNAMP_VERSION', '8.1.14');
